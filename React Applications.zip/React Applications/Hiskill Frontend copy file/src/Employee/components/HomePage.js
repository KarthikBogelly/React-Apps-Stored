import React from 'react'
import {HvTypography} from "@hitachivantara/uikit-react-core";
export default function HomePage() {
  return (
  <center>
  <div 
  style={{
    width: 400,
    alignItems: 'center'
  }}
>
  <HvTypography
  style={{marginTop:200}}
    variant="display"
  >
    This is Home Page !
  </HvTypography>
  </div>
  </center>

  )
}
