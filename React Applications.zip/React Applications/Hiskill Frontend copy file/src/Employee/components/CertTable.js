import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  HvTableCell,
  HvTableRow,
  HvTableBody,
  HvTableHeader,
  HvTableHead,
  HvTableContainer,
  HvTable,
  HvGlobalActions
} from "@hitachivantara/uikit-react-core";

export default function CertTable() {
  const [certs, setCertifications] = useState([]);
  
  useEffect(() => {
    axios.get('http://13.234.20.12:8080/api/v1/certifications/1')
      .then((response) => {
        setCertifications(response.data);
        console.log(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  // useEffect(() => {
  //   const sampleData = [
  //     {
  //       "name": "Certification 1",
  //       "url": "https://example.com/cert1",
  //       "expiryDate": "2023-12-31"
  //     },
  //     {
  //       "name": "Certification 2",
  //       "url": "https://example.com/cert2",
  //       "expiryDate": "2024-06-30"
  //     },
  //     {
  //       "name": "Certification 3",
  //       "url": "https://example.com/cert3",
  //       "expiryDate": "2022-09-15"
  //     }
  //   ];

  //   setCertifications(sampleData);
  // }, []);

  return (
    <div>
      <div className="cert-table" style={{ width: 900 }}>
      <HvGlobalActions title="My Certifications">
        </HvGlobalActions>
        <div style={{ marginTop: "20px" }}>
          <HvTableContainer>
            <HvTable>
              <HvTableHead>
                <HvTableRow>
                  <HvTableHeader>S.No.</HvTableHeader>
                  <HvTableHeader>Certification Name</HvTableHeader>
                  <HvTableHeader>Certification URL</HvTableHeader>
                  <HvTableHeader>Expiry Date</HvTableHeader>
                </HvTableRow>
              </HvTableHead>
              <HvTableBody>
                {certs.map((certification, index) => (
                  <HvTableRow key={index} hover>
                    <HvTableCell>{index + 1}</HvTableCell>
                    <HvTableCell>{certification.certificationName}</HvTableCell>
                    <HvTableCell>{certification.certificationUrl}</HvTableCell>
                    <HvTableCell>{certification.expiredDate}</HvTableCell>
                  </HvTableRow>
                ))}
              </HvTableBody>
            </HvTable>
          </HvTableContainer>
        </div>
      </div>
    </div>
  );
}
