import React from 'react'
import {Link} from 'react-router-dom';
import {HvTypography,HvButton} from '@hitachivantara/uikit-react-core';

export default function LogoutPage() {
  return (
    <div>
    <center>
    <HvTypography style={{marginTop:200, marginBottom:20}} variant="display">
      Logged out successfully!
    </HvTypography>
    <Link to="/loginpage">
    <HvButton
    overrideIconColors
    radius="base"
    variant="primary"
    >
    Login
    </HvButton>
    </Link>
    <HvTypography style={{marginTop: 10}}
        variant="body">
        click here to login !
    </HvTypography>
    </center>
    </div>
  )
}
