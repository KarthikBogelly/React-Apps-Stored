import React, { useState } from 'react';
import {Link} from 'react-router-dom';
import {
  HvVerticalNavigation,
  HvVerticalNavigationTree,
  HvVerticalNavigationActions,
  HvVerticalNavigationAction,
  HvVerticalNavigationHeader
} from "@hitachivantara/uikit-react-core";
import { User, LogOut } from "@hitachivantara/uikit-react-icons";

export default function Sidebar() {
  const [currentPage, setCurrentPage] = useState('00');

  const handleNavigationChange = (id) => {
    setCurrentPage(id);
  };

  return (
    <div>
      <div
        style={{
          display: 'flex',
          height: "100vh",
          width: 220,
          position: 'fixed',
          boxShadow: '2px 0 4px rgba(0, 0, 0, 0.1)'
        }}
      >
        <HvVerticalNavigation
          collapsedMode="simple"
          id="sample1"
          open
        >
          <HvVerticalNavigationHeader title="HiSkill" />
          <HvVerticalNavigationTree
            aria-label="Example 1 navigation"
            data={[
              {
                id: '00',
                label: 'Home',
                selected: currentPage === '00',
                href: '/home',
              },
              {
                id: '01',
                label: 'My Skills',
                selected: currentPage === '01',
                href: '/skilltable',
              },
              {
                id: '02',
                label: 'Add Skill',
                selected: currentPage === '02',
                href: '/addskill',
              },
              {
                id: '03',
                label: 'My Certifications',
                selected: currentPage === '03',
                href: '/certtable',
              }
            ]}
            onChange={handleNavigationChange}
          />
          <HvVerticalNavigationActions>
            <HvVerticalNavigationAction
              icon={<User />}
              label="Profile"
            />
            <Link to="/logoutpage">
            <HvVerticalNavigationAction
              icon={<LogOut />}
              label="Logout"
            />
            </Link>
          </HvVerticalNavigationActions>
        </HvVerticalNavigation>
      </div>
    </div>
  )
}




