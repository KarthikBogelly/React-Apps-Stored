import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  HvTableCell,
  HvCheckBox,
  HvTableRow,
  HvTableBody,
  HvTableHeader,
  HvTableHead,
  HvTableContainer,
  HvTable,
  HvGlobalActions,
  HvInput,
  HvButton,
  HvBanner,
} from "@hitachivantara/uikit-react-core";

export default function SkillTable() {
  const [skills, setSkills] = useState([]);
  const [editedSkills, setEditedSkills] = useState([]);
  const [isBannerOpen, setIsBannerOpen] = useState(false);

  useEffect(() => {
    axios.get('http://13.234.20.12:8080/api/v1/skillemp/1')
      .then((response) => {
        setSkills(response.data);
        setEditedSkills(response.data.map((skill) => ({ ...skill, editing: false })));
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const handleEdit = (id) => {
    setEditedSkills((prevSkills) => {
      return prevSkills.map((skill) => {
        if (skill.id === id) {
          return { ...skill, editing: true };
        }
        return { ...skill, editing: false }; 
      });
    });
  };
  
  const handleCancel = (id) => {
    setEditedSkills((prevSkills) => {
      return prevSkills.map((skill) => {
        if (skill.id === id) {
          return { ...skill, editing: false };
        }
        return skill;
      });
    });
  };
  

  const handleUpdate = (id, num) => {

    const updatedRating = parseInt(num) || 0;
  if (updatedRating < 1 || updatedRating > 5) {
    alert('Invalid rating. Please enter a number between 1 and 5.');
    return;
  }
    setEditedSkills((prevSkills) => {
      const updatedSkills = prevSkills.map((skill) => {
        if (skill.id === id) {
          return { ...skill, proficiencylevel: parseInt(num) || skill.proficiencylevel, editing: false };
        }
        return skill;
      });
      return updatedSkills;
    });

    axios
      .put(`http://13.234.20.12:8080/api/v1/skillemp/${id}`, { proficiencylevel: parseInt(num) || 0 })
      .then((response) => {
        console.log('Proficiency level updated successfully');
        setIsBannerOpen(true);
        setTimeout(() => {
          setIsBannerOpen(false);
        }, 5000);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  return (
    <div>
      <div className="skill-table" style={{ width: 900 }}>
        <HvGlobalActions title="My Skills"></HvGlobalActions>
        <div style={{ marginTop: "20px" }}>
          <HvTableContainer>
            <HvTable>
              <HvTableHead>
                <HvTableRow>
                <HvTableHeader>S.No.</HvTableHeader>
                  <HvTableHeader>Skill Id</HvTableHeader>
                  <HvTableHeader>Proficiency</HvTableHeader>
                  <HvTableHeader>Recently Used</HvTableHeader>
                  <HvTableHeader>Actions</HvTableHeader>
                </HvTableRow>
              </HvTableHead>
              <HvTableBody>
                {editedSkills.map((skill,index) => (
                  <HvTableRow key={skill.id} hover>
                    <HvTableCell >
                    {index+1}
                    </HvTableCell>
                    <HvTableCell>{skill.skillid}</HvTableCell>
                    <HvTableCell>
                      {skill.editing ? (
                        <HvInput
                          value={skill.proficiencylevel}
                          onChange={(event) => {
                            const { value } = event.target;
                            setEditedSkills((prevSkills) =>
                              prevSkills.map((prevSkill) =>
                                prevSkill.id === skill.id
                                  ? { ...prevSkill, proficiencylevel: value }
                                  : prevSkill
                              )
                            );
                          }}
                          style={{ width: '100px' }} 
                        />
                      ) : (
                        skill.proficiencylevel
                      )}
                    </HvTableCell>
                    <HvTableCell>{skill.lastused}</HvTableCell>
                    <HvTableCell>
                      {skill.editing ? (
                        <>
                          <HvButton
                              variant="primary"
                              size="xs"
                              style={{marginBottom:'2px', cursor:'pointer'}} 
                              onClick={() => handleUpdate(skill.id, skill.proficiencylevel)}> 
                            Update
                            </HvButton>
                          <HvButton
                              variant="secondary"
                              size="xs"
                              style={{ marginLeft: '10px', cursor: 'pointer', backgroundColor: '#CC0000', color: 'white'}}
                              onClick={() => handleCancel(skill.id)}
                            >
                              Cancel
                            </HvButton>
                        </>
                        ) : (
                          <HvButton
                              variant="primary"
                              size="xs"
                              style={{cursor:'pointer'}} 
                              onClick={() => handleEdit(skill.id)}
                            > 
                            Edit
                            </HvButton>
                      )}
                    </HvTableCell>
                  </HvTableRow>
                ))}
              </HvTableBody>
            </HvTable>
          </HvTableContainer>
        </div>
      </div>
      {isBannerOpen && (
        <HvBanner
          label="Proficiency level sucessfully updated"
          offset={0}
          open
          showIcon
          variant="success"
          onClose={() => setIsBannerOpen(false)}
        />
      )}
    </div>
  );
}
