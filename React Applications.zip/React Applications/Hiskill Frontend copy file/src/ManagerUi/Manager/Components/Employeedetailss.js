import React, { useMemo, useState, useEffect } from "react";
import {
  HvTableContainer,
  HvTable,
  HvTableHead,
  HvTableBody,
  HvTableRow,
  HvTableHeader,
  HvTableCell,
  HvPagination,
  useHvData,
  useHvPagination,
} from "@hitachivantara/uikit-react-core";
import "./Employeedetailss.css";
import { useNavigate } from "react-router-dom";


const EmployeeTable = ({ columns }) => {
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [employees, setEmployees] = useState([]);
  
  const navigate=useNavigate();
  useEffect(() => {
    if (selectedEmployee) {
    // {console.log(selectedEmployee)}
      navigate("/SkillView", { state: { emp: selectedEmployee } });
    }
  });
 

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/v1/manager");
        const json = await response.json();
        //  console.log(json);
        const filteredEmployees = json.filter(
          (employee) => employee.managerid === 1000
        );
        // console.log(filteredEmployees);
        setEmployees(filteredEmployees);
      } catch (error) {
        console.error("Error fetching employee data:", error);
      }
    };

    fetchEmployees();
  }, []);

  const getColumns = () => [
    {
      Header: "Employee Name",
      accessor: "name",
    },
    {
      Header: "Employee ID",
      accessor: "id",
    },
    {
      Header: "Role",
      accessor: "role",
    },
  ];

  const makeData = (employees) => {
    return employees.map((employee) => ({
      name: employee.empName,
      id: employee.empId,
      role: employee.role,
    }));
  };

  const data = useMemo(() => makeData(employees), [employees]);

  const {
    getTableProps,
    getTableBodyProps,
    prepareRow,
    headerGroups,
    page,
    state: { pageSize },
    getHvPaginationProps,
  } = useHvData({ columns, data }, useHvPagination);

  const EmptyRow = () => (
    <HvTableRow>
      <HvTableCell colSpan={columns.length} />
    </HvTableRow>
  );
  
 

  return (
    <>
      <div className="header">
        <b>Employee details:</b>
      </div>
      <div className="outerbox">
        <div className="table-box">
          <HvTableContainer>
            <HvTable {...getTableProps()}>
              <HvTableHead>
                {headerGroups.map((headerGroup) => (
                  <HvTableRow {...headerGroup.getHeaderGroupProps()}>
                    {headerGroup.headers.map((col) => (
                      <HvTableHeader {...col.getHeaderProps()}>
                        {col.render("Header")}
                      </HvTableHeader>
                    ))}
                  </HvTableRow>
                ))}
              </HvTableHead>
              <HvTableBody {...getTableBodyProps()}>
                {pageSize &&
                  page.map((row, i) => {
                    prepareRow(row);
                    return (
                      <HvTableRow
                        {...row.getRowProps()}
                        key={i}
                        
                        onClick={() =>setSelectedEmployee(row.original)}
                        
                        style={{ cursor: "pointer" }}
                     
                      >
                       
                        {row.cells.map((cell) => (
                          <HvTableCell
                            {...cell.getCellProps()}
                            key={cell.column.id}
                          >
                            {cell.render("Cell")}
                          </HvTableCell>
                        ))}
                      </HvTableRow>
                    );
                  })}
                {!pageSize && <EmptyRow />}
              </HvTableBody>
            </HvTable>
          </HvTableContainer>
          {page?.length ? (
            <HvPagination {...getHvPaginationProps?.()} />
          ) : undefined}
        </div>
      </div>
    </>
  );
};

export default EmployeeTable;
