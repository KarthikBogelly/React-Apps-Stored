import axios from "axios";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { HvSlider } from "@hitachivantara/uikit-react-core";
import './Employeedetailss.css'
import {
  HvTableCell,
  HvTableRow,
  HvTableBody,
  HvTableHeader,
  HvTableHead,
  HvTableContainer,
  HvTable,
  HvGlobalActions,
  HvButton,
} from "@hitachivantara/uikit-react-core";
function SkillEmpComponent() {
  const [skills, setSkills] = useState([]);
  const [skillname, setskillname] = useState([]);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [newRating, setNewRating] = useState();
  const [edibutton, seteditbutton] = useState(true);
  const location = useLocation();
  const { emp } = location.state;
  const employeeId = emp.id;

  // console.log(emp)
  useEffect(() => {
    fetchSkills();
  }, []);
  useEffect(() => {
    fetchskillName();
  }, []);
  const fetchskillName = () => {
    axios
      .get("http://localhost:8080/api/v1/skillmaster")
      .then((response) => {
        setskillname(response.data);
        //  console.log(skillname);
      })
      .catch((error) => {
        console.log("error foung");
      });
  };
  const fetchSkills = () => {
    axios
      .get("http://localhost:8080/api/v1/skillemp")
      .then((response) => {
        const filteredSkills = response.data.filter(
          (skill) => skill.empId === employeeId
        );
        setSkills(filteredSkills);
      })
      .catch((error) => {
        console.log("Error occurred:", error);
      });
  };
  const navigate=useNavigate();
  console.log(skills)
  const handlesubmitaddskill=()=>{
    navigate('/addskill',{ state: { empid: employeeId } })
  }

  // {console.log(skillname)}
  const handleUpdateSkill = (skillId) => {
    const skillToUpdate = skills.find((skill) => skill.id === skillId);

    const updatedSkill = {
      ...skillToUpdate,
      proficiencylevel: newRating,
    };

    const updatedSkills = skills.map((skill) => (skill.id === skillId ? updatedSkill : skill));

    setSkills(updatedSkills);
    console.log()
    axios.put(`http://localhost:8080/api/v1/skillemp/${skillId}`, updatedSkill)
      .then((response) => {
        console.log('Skill updated:', response.data);
      })
      .catch((error) => {
        console.error('Error updating skill:', error);
        setSkills(skills);
      });
    setSelectedSkill(null);
    setNewRating(null);
  };
  return (
    <div>
      <h1 className="heading"><b>Skills for Employee ID: {employeeId}</b></h1>
      <div className="table-box">
      <HvTableContainer>
        <HvTable>
          <HvTableHead>
            <HvTableRow>
              <HvTableHeader >Skill ID</HvTableHeader>
              <HvTableHeader >skillName</HvTableHeader>
              <HvTableHeader >Proficiency</HvTableHeader>
              <HvTableHeader >Actions</HvTableHeader>
            </HvTableRow>
          </HvTableHead>
          <HvTableBody>
            {skills.map((skill) => (
              <HvTableRow key={skill.id} hover>
                <HvTableCell >{skill.skillid}</HvTableCell>
                <HvTableCell >
                  {skillname.map(
                    (skillnamess) =>
                      skillnamess.skillId === skill.skillid && (
                        <p key={skillnamess.id}>{skillnamess.skillname}</p>
                      )
                  )}
                </HvTableCell>

                <HvTableCell >
             
                  {skill.proficiencylevel}
                </HvTableCell>
                <HvTableCell>
                        
                        {selectedSkill === skill.id ? (
                          <div>
                            <input
                              type="number"
                              value={newRating}
                              min='1'
                              max='5'
                              onChange={(e) => setNewRating(parseInt(e.target.value))}
                              style={{width: '20%', border: '3px solid grey', padding: '4px', borderRadius: '2px'}}
                            />
                            <HvButton
                              variant="primary"
                              size="xs"
                              style={{marginLeft:'10px',marginBottom:'2px', cursor:'pointer'}} 
                              onClick={() => 
                              {
                                if(newRating >= 1 && newRating <= 5)
                                {
                                  handleUpdateSkill(skill.id);
                                }
                                else
                                {
                                  alert("Please select rating between 1 to 5");
                                }
                              }}> 
                            Update
                            </HvButton>
                            <HvButton
                              variant="secondary"
                              size="xs"
                              style={{ marginLeft: '10px', cursor: 'pointer', backgroundColor: '#CC0000', color: 'white'}}
                              onClick={() => setSelectedSkill(null)}
                            >
                              Cancel
                            </HvButton>
                          </div>
                        ) : (
                          <HvButton
                              variant="primary"
                              size="xs"
                              style={{cursor:'pointer'}} 
                              onClick={() => setSelectedSkill(skill.id)}
                            > 
                            Edit
                            </HvButton>
                        )}
                      </HvTableCell>
               
              </HvTableRow>
            ))}
          </HvTableBody>
        </HvTable>
      </HvTableContainer>
      
      </div>
      
        <HvButton 
        className="addskill"
        onClick={handlesubmitaddskill}
        >
          Addskill
        </HvButton>
      
    </div>
    
  );
}

export default SkillEmpComponent;
