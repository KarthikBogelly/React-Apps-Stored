import React from 'react'
import '../Components.css'
function Home() {
  return (
    <div>
      <div id='Hi' >
        Hi Skill
      </div>
      <hr className="line" /> {/* Add this line */}
      <div id='Id2'>
       Hiskill enables to an employee add their skills.
      </div>
  </div>
  )
}

export default Home
