import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Sidebar from '../Sidebar';
import Home from './Home';
import Employeedetailss from './Employeedetailss';
import './Employeedetailss.css'
import SkillView from './SkillView';
import AddSkill from './AddSkill'
function ManagerRoutes() {
  return (
    <BrowserRouter>
    <div className="App">
      <div className="Sidebar">
      <Sidebar/>
      </div>
     <div className="content">
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/employeedetailss" element={<Employeedetailss />} />
        <Route path="/SkillView" element={<SkillView />} />
        <Route path="/addskill" element={<AddSkill/>}/>
      </Routes>
      </div>
      </div>
  </BrowserRouter>
  );
}

export default ManagerRoutes;
