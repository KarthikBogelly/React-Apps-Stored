import React, { useState, useEffect } from 'react';

const generateAbstractColor = () => {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

const SkillHeatmap = ({ skill, isSelected, onClick }) => (
  <div
    className={`skill-heatmap-item ${isSelected ? 'selected' : ''}`}
    style={{ backgroundColor: skill.color, gridColumnEnd: `span ${skill.employees.length}` }}
    onClick={onClick}
  >
    <div className="skill-name">{skill.name}</div>
  </div>
);

const EmployeeHeatmap = ({ employees }) => {
  const maxRating = Math.max(...employees.map((employee) => employee.rating));

  const getGradientColor = (rating) => {
    const percentage = (rating / maxRating) * 100;
    const hue = Math.floor(120 - (percentage * 120) / 100); // Adjust the hue range as needed
    return `hsl(${hue}, 100%, 50%)`;
  };

  return (
    <div className="employee-heatmap">
      <div className="employee-grid">
        {employees.map((employee) => (
          <div
            key={employee.id}
            className="employee-grid-item"
            style={{ backgroundColor: getGradientColor(employee.rating) }}
          >
            <div className="employee-name">{employee.name}</div>
            <div className="employee-rating">Rating: {employee.rating}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

const COPDashboard = () => {
  const [skills, setSkills] = useState([]);
  const [selectedSkill, setSelectedSkill] = useState(null);

  useEffect(() => {
    // Dummy skills data for testing
    const dummySkills = [
      {
        id: 1,
        name: 'Java',
        employees: [
          { id: 1, name: 'John', rating: 5 },
          { id: 2, name: 'Saran', rating: 6 },
          { id: 3, name: 'Jahnavi', rating: 7 },
        ],
        color: generateAbstractColor()
      },
      {
        id: 2,
        name: 'React',
        employees: [
          { id: 6, name: 'Sujitha', rating: 6 },
          { id: 7, name: 'Shinde', rating: 7 },
          { id: 8, name: 'Shashi', rating: 8 },
          { id: 9, name: 'Sahithi', rating: 9 },
          { id: 10, name: 'Arun', rating: 10 }
        ],
        color: generateAbstractColor()
      },
      {
        id: 3,
        name: 'Angular',
        employees: [
          { id: 11, name: 'Nivas', rating: 4 },
          { id: 12, name: 'Shiva', rating: 6 },
          { id: 13, name: 'Mounika', rating: 7 },
          { id: 14, name: 'Ganesh', rating: 8 },
        ],
        color: generateAbstractColor()
      },
      {
        id: 4,
        name: 'Mobile',
        employees: [
          { id: 16, name: 'Prathyusha', rating: 3 },
          { id: 17, name: 'Lakshmi', rating: 5 },
          { id: 18, name: 'Himani', rating: 6 },
          { id: 19, name: 'Vishnu', rating: 8 },
          { id: 20, name: 'Raj', rating: 9 }
        ],
        color: generateAbstractColor()
      },
      {
        id: 5,
        name: 'Python',
        employees: [
          { id: 21, name: 'Sony', rating: 2 },
          { id: 22, name: 'Sophia', rating: 4 },
          { id: 23, name: 'David', rating: 6 },
          { id: 24, name: 'John', rating: 8 },
          { id: 25, name: 'Jack', rating: 9 }
        ],
        color: generateAbstractColor()
      },
    ];

    setSkills(dummySkills);
  }, []);

  const handleSkillClick = (skill) => {
    setSelectedSkill(skill);
  };

  return (
    <div className="cop-dashboard">
      <div className="skills-heatmap">
        <h2>Skills Heat Map</h2>
        <div className="skill-heatmap">
          {skills.map((skill) => (
            <SkillHeatmap
              key={skill.id}
              skill={skill}
              isSelected={selectedSkill && selectedSkill.id === skill.id}
              onClick={() => handleSkillClick(skill)}
            />
          ))}
        </div>
      </div>

      <div className="employee-heatmap">
        <h2>Employee Heat Map</h2>
        {selectedSkill && (
          <EmployeeHeatmap employees={selectedSkill.employees} />
        )}
      </div>
    </div>
  );
};

export default COPDashboard;
