import React from 'react';
import { useNavigate } from 'react-router-dom';
import { HvGlobalActions, HvInput, HvDropdown, HvButton } from '@hitachivantara/uikit-react-core';

const Home = () => {
  const navigate = useNavigate();
  const handleGetStarted = () => {
    navigate('/Coursedetails');
  };
  return (
    <div className="App" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start', minHeight: '100vh' }}>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px', marginTop: '20px' }}>
        <HvGlobalActions title="Welcome to SkillUpgrade" style={{ margin: '0 auto', whiteSpace: 'nowrap', paddingRight: '250px' }} />
      </div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: '200px', marginRight: '10px' }}>
          <HvDropdown
            aria-label="Filter Skills"
            classes={{
              dropdown: 'css-8atqhb',
              root: 'css-obmc51',
              rootList: 'css-1a61zwt',
            }}
            onChange={function kc() {}}
            values={[
              { label: 'All', selected: true, value: 'All' },
              { label: 'Java', value: 'Java' },
              { label: 'Angular', value: 'Angular' },
              { label: 'React', value: 'React' },
            ]}
          />
        </div>
        <HvInput
          aria-label="Search Skills data"
          classes={{
            root: 'css-8atqhb',
          }}
          onEnter={function kc() {}}
          placeholder="Search"
          suggestionListCallback={function kc() {}}
          type="search"
          style={{ width: '200px' }}
        />
      </div>
      <div style={{ marginTop: '20px' }}>
        <HvButton variant="primary" onClick={handleGetStarted}>Get Started</HvButton>
      </div>
    </div>
  );
};

export default Home;