import React from 'react'
import Sidebar from './Sidebar';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './Home';
import Coursedetails from './CourseDetails';
export default function SklUpgRoutes() {
  return (
      <BrowserRouter>
  <div className="App">
    <div className="Sidebar">
      <Sidebar/>
      </div >
      <div className="content">
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/Coursedetails" element={<Coursedetails />} />
      </Routes>
  </div>
  </div>
  </BrowserRouter>
  )
}

