import React, { useState, useEffect } from 'react';
//import CourseData from './CourseData.json';
import axios from 'axios';
import {
  HvTypography,
  HvCard,
  HvPanel,
  HvBox,
  HvListContainer,
  HvListItem,
  HvAccordion,
  HvProgressBar,
  HvButton,
} from '@hitachivantara/uikit-react-core';
import { CompletedStep, PlayVideo, Code, Bookmark, Contract, MultiDevices, Doc, } from "@hitachivantara/uikit-react-icons";

const Coursedetails = () => {
  const[courses, setCourses] = useState([]);
  useEffect(()=> {
    axios.get("http://localhost:8080/courses/get")
    .then((response)=> {
      setCourses(response.data);
      console.log(response.data);
    })
    .catch((error) => {
      console.error(error);
    })
  }, []);
  return (
    <>
      <div style={{
        flex: '1',
        paddingLeft: '250px',
        paddingRight: '30px',
        backgroundColor: '#edf1f1',
      }}>
        <HvPanel style={{ width: '100%', borderBottom: '3px solid black', backgroundColor: '#fefefe', }}>
          <div
            style={{
              paddingRight: '10px',
              position: 'relative',
            }}
          >
            <HvCard
              bgcolor="atmo1"
              statusColor="negative"
              style={{
                width: '100% !important', 
                left: 0,
                right: 0,
                overflow: 'hidden',
              }}
            ></HvCard>
            <HvTypography
              variant="title1"
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                paddingTop: 40,
                paddingBottom: 30,
                display: 'flex',
                color: '#141482',
              }}
            >
          
              Welcome to Course - {courses.map(ele => {
                return (
                  <HvTypography variant="title1" style={{ paddingLeft: 5, color: '#141482', }}>
                    {ele.skillname}
                  </HvTypography>
                );
              })}
            </HvTypography>
          </div >

          <div
            style={{
              paddingTop: '27px',
              padding: 5,
            }}
          >
            <HvTypography variant="title4">
              {courses.map(ele => {
                return (
                  <HvTypography variant="title4">
                    {ele.about}
                  </HvTypography>
                );
              })}
            </HvTypography>
          </div>

          <div
            style={{
              display: 'flex',
              paddingTop: 20,
            }}>

            <div
              style={{
                float: 'left',
                width: '50%',
                padding: 5,
              }}
            >
              <HvTypography variant="label">
                Created By
              </HvTypography>
              <HvTypography>
                Joseph Lio
              </HvTypography>
            </div>
            <div
              style={{
                float: 'left',
                width: '50%',
                padding: 5,
              }}
            >
              <HvTypography variant="label">
                Last Updated
              </HvTypography>
              <HvTypography>
                Aug 30, 2023
              </HvTypography>
            </div>
            <div
              style={{
                float: 'left',
                width: '50%',
                padding: 5,
              }}
            >
              <HvTypography variant="label">
                Language
              </HvTypography>
              <HvTypography>
                English
              </HvTypography>
            </div>

          </div>
        </HvPanel >
      </div >
      < div
        style={{
          margin: 20,
          display: 'flex',
          flexDirection: 'row',  
          flex: '1',
          paddingLeft: '250px',
          paddingRight: '30px',
          backgroundColor: '#edf1f1',       
        }}
      >
        <HvCard
          bgcolor="atmo1"
          style={{
            width: '70%',
            marginRight: 5,
          }}
        >
          <HvBox
            sx={{
              marginBottom: 'var(--uikit-space-sm)',
            }}
          >
            <br />
            <HvTypography variant="title3">
              What we will Learn
            </HvTypography>
            <div
              style={{
                backgroundColor: 'var(--uikit-colors-atmo1)',
                float: 'left ',
                padding: 20,
                position: 'relative',
                flexBasis: 100,
              }}
            >

              <HvListContainer
                interactive
              >
                {courses.map(ele => {
                  return (
                    <div key={ele.skillname}>
                      <HvListItem startAdornment={<CompletedStep />}>
                        {ele.learning[0]}
                      </HvListItem>
                      <HvListItem startAdornment={<CompletedStep />}>
                        {ele.learning[1]}
                      </HvListItem>
                      <HvListItem startAdornment={<CompletedStep />}>
                        {ele.learning[2]}
                      </HvListItem>
                      <HvListItem startAdornment={<CompletedStep />}>
                        {ele.learning[3]}
                      </HvListItem>
                    </div>
                  );
                })}
              </HvListContainer>
            </div>
          </HvBox>
        </HvCard>

        {/* Course details */}
        <HvCard
          bgcolor="atmo1"
          style={{
            width: '30%',
            marginRight: 5,
          }}
        >
          <HvBox
            sx={{
              marginBottom: 'var(--uikit-space-sm)'
            }}
          >
            <br />
            <HvTypography variant="title3">
              Course details
            </HvTypography>
            <div
              style={{
                backgroundColor: 'var(--uikit-colors-atmo1)',
                padding: 20,
                position: 'relative',
                flexBasis: 100,
              }}
            >
              <HvListContainer
                interactive
              >
                {courses.map(ele => {
                  return (
                    <div key={ele.skillname}>
                      <HvListItem startAdornment={<PlayVideo />}>
                        time - {ele.Week2} hrs
                      </HvListItem>
                      <HvListItem startAdornment={<Code />}>
                        No. of exercises - {ele.exercises}
                      </HvListItem>
                      <HvListItem startAdornment={<Bookmark />}>
                        No. of articles - {ele.articles}
                      </HvListItem>
                      <HvListItem startAdornment={<Contract />}>
                        certificate - {ele.certificate}
                      </HvListItem>
                    </div>
                  );
                })}
              </HvListContainer>
            </div>
          </HvBox>
        </HvCard>
      </div >

      {/* Course Content */}
      <div
        style={{
          margin: 20,
          display: 'flex',
          flexDirection: 'row',
          flex: '1',
          paddingLeft: '250px',
          paddingRight: '30px',
          backgroundColor: '#edf1f1',
        }
        }
      >
        <HvCard
          bgcolor="atmo1"
          style={{
            width: '100%',
            marginRight: 5,
          }}
        >
          <HvBox
            sx={{
              marginBottom: 'var(--uikit-space-sm)'
            }}
          >
            <br />
            <HvTypography variant="title3">
              Course Content
            </HvTypography>
          </HvBox>

          <div
            style={{
              display: 'flex:',
              flexDirection: 'column'
            }}
          >
            <div
              style={{
                alignItems: 'center',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-around',
                margin: 'auto',
                marginBottom: 40,
                marginTop: 20,
                width: 400
              }}
            >
              <HvTypography variant="label">
                See Your Progress Here!
              </HvTypography>
              <HvProgressBar status="inProgress" value={80} />
            </div>
          </div>
          </HvCard>
          </div>
          <div>
            <HvButton
              variant="primarySubtle"
              style={{ margin: '0 10px', width: 150 }}
            >
              Assign Course
            </HvButton>
            <HvButton
              variant="primarySubtle"
              style={{ margin: '0 10px', width: 150 }}
            >
              Customize Course
            </HvButton>
          </div>

          <HvBox
            sx={{
              maxWidth: '100%',
            }}
          > 
          </HvBox>
            {courses.map(ele => {
              return (
                <div>
                  <div key={ele.skillname}>
                  <div style={{ paddingLeft: 40, paddingBottom: 10 }}>
  {ele.plan && ele.plan.Week1 && (
    <div >
      <HvAccordion
        headingLevel={4}
        id="item1"
        label={`${ele.plan.Week1.label} - ${ele.plan.Week1.about}`}
        style={{
          cursor: 'pointer',
          padding: '10px',
          width: '100%',
          border: 'none',
          textAlign: 'left',
          outline: 'none',
          marginLeft:'200px',
        }}
      >
        {ele.plan.Week1.days && Object.keys(ele.plan.Week1.days).map((dayKey)=> (
          <HvAccordion
            headingLevel={4}
            id="item1"
            label={`${ele.plan.Week1.days[dayKey].dLabel} - ${ele.plan.Week1.days[dayKey].name}`}
            style={{
              cursor: 'pointer',
              padding: '10px',
              width: '100%',
              border: 'none',
              textAlign: 'left',
              outline: 'none'
            }}
          >
            <div style={{ paddingLeft: 40 }}>
              <HvListContainer condensed interactive>
                <HvTypography style={{ paddingLeft: 20, fontWeight: 'bold' }}>Details</HvTypography>
                <HvListItem>
                  <a href={'https://www.udemy.com/'} target="_blank" rel="noopener noreferrer">
                    {ele.plan && ele.plan.Week1 && ele.plan.Week1.days && ele.plan.Week1.days[dayKey] && ele.plan.Week1.days[dayKey].details && ele.plan.Week1.days[dayKey].details}
                    
                  </a>
                </HvListItem>
                
                <div style={{ paddingLeft: 40, paddingBottom: 10 }}>
                  {/* <HvListItem startAdornment={<MultiDevices />} style={{ float: 'left' }}>
                    {ele.plan.Week1.days[dayKey] && ele.plan.Week1.days[dayKey].mode && ele.plan.Week1.days[dayKey].mode.length >= 2 && (
                      <>
                        mode - {ele.plan.Week1.days[dayKey].mode[0]} / ele.plan.Week1.days[dayKey].mode[1]}
                      </>
                    )}
                  </HvListItem> */}
                  <HvListItem startAdornment={<MultiDevices />} style={{ float: 'left' }}>
                    {ele.plan.Week1.days[dayKey] && ele.plan.Week1.days[dayKey].mode && ele.plan.Week1.days[dayKey].mode.length >= 2 && (
                      <>
                        mode - {ele.plan.Week1.days[dayKey].mode[0]} / {ele.plan.Week1.days[dayKey].mode[1]}
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<PlayVideo />} style={{ float: 'left' }}>
                    {ele.plan.Week1.days[dayKey] && (
                      <>
                        time - {ele.plan.Week1.days[dayKey].time} mins
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<CompletedStep />}>
                    {ele.plan.Week1.days[dayKey] && ele.plan.Week1.days[dayKey]['prerequisites'] && (
                      <>
                        prerequisites - {ele.plan.Week1.days[dayKey]['prerequisites']}
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<Doc />} style={{}}>
                    {ele.plan.Week1.days[dayKey] && ele.plan.Week1.days[dayKey].references && ele.plan.Week1.days[dayKey].references.length >= 2 && (
                      <>
                        references -
                        <a href={'https://www.udemy.com/'} target="_blank" rel="noopener noreferrer">
                          {ele.plan.Week1.days[dayKey].references[0]}
                        </a>
                        <a href={'https://www.coursera.com/'} target="_blank" rel="noopener noreferrer">
                          {ele.plan.Week1.days[dayKey].references[1]}
                        </a>
                      </>
                    )}
                  </HvListItem>
                </div>
              </HvListContainer>
            </div>
          </HvAccordion>
        )
        )}
      </HvAccordion>
    </div>
  )}
  {ele.plan && ele.plan.Week2 && (
    <div >
      <HvAccordion
        headingLevel={4}
        id="item1"
        label={`${ele.plan.Week2.label} - ${ele.plan.Week2.about}`}
        style={{
          cursor: 'pointer',
          padding: '10px',
          width: '100%',
          border: 'none',
          textAlign: 'left',
          outline: 'none',
          marginLeft:'200px',
        }}
      >
        {ele.plan.Week2.days && Object.keys(ele.plan.Week2.days).map((dayKey)=> (
          <HvAccordion
            headingLevel={4}
            id="item1"
            label={`${ele.plan.Week2.days[dayKey].dLabel} - ${ele.plan.Week2.days[dayKey].name}`}
            style={{
              cursor: 'pointer',
              padding: '10px',
              width: '100%',
              border: 'none',
              textAlign: 'left',
              outline: 'none'
            }}
          >
            <div style={{ paddingLeft: 40 }}>
              <HvListContainer condensed interactive>
                <HvTypography style={{ paddingLeft: 20, fontWeight: 'bold' }}>Details</HvTypography>
                <HvListItem>
                  <a href={'https://www.udemy.com/'} target="_blank" rel="noopener noreferrer">
                    {ele.plan && ele.plan.Week2 && ele.plan.Week2.days && ele.plan.Week2.days[dayKey] && ele.plan.Week2.days[dayKey].details && ele.plan.Week2.days[dayKey].details}
                    
                  </a>
                </HvListItem>
                
                <div style={{ paddingLeft: 40, paddingBottom: 10 }}>
                  {/* <HvListItem startAdornment={<MultiDevices />} style={{ float: 'left' }}>
                    {ele.plan.Week1.days[dayKey] && ele.plan.Week1.days[dayKey].mode && ele.plan.Week1.days[dayKey].mode.length >= 2 && (
                      <>
                        mode - {ele.plan.Week1.days[dayKey].mode[0]} / ele.plan.Week1.days[dayKey].mode[1]}
                      </>
                    )}
                  </HvListItem> */}
                  <HvListItem startAdornment={<MultiDevices />} style={{ float: 'left' }}>
                    {ele.plan.Week2.days[dayKey] && ele.plan.Week2.days[dayKey].mode && ele.plan.Week2.days[dayKey].mode.length >= 2 && (
                      <>
                        mode - {ele.plan.Week2.days[dayKey].mode[0]} / {ele.plan.Week2.days[dayKey].mode[1]}
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<PlayVideo />} style={{ float: 'left' }}>
                    {ele.plan.Week1.days[dayKey] && (
                      <>
                        time - {ele.plan.Week2.days[dayKey].time} mins
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<CompletedStep />}>
                    {ele.plan.Week2.days[dayKey] && ele.plan.Week2.days[dayKey]['prerequisites'] && (
                      <>
                        prerequisites - {ele.plan.Week2.days[dayKey]['prerequisites']}
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<Doc />} style={{}}>
                    {ele.plan.Week2.days[dayKey] && ele.plan.Week2.days[dayKey].references && ele.plan.Week2.days[dayKey].references.length >= 2 && (
                      <>
                        references -
                        <a href={'https://www.udemy.com/'} target="_blank" rel="noopener noreferrer">
                          {ele.plan.Week2.days[dayKey].references[0]}
                        </a>
                        <a href={'https://www.coursera.com/'} target="_blank" rel="noopener noreferrer">
                          {ele.plan.Week2.days[dayKey].references[1]}
                        </a>
                      </>
                    )}
                  </HvListItem>
                </div>
              </HvListContainer>
            </div>
          </HvAccordion>
        )
        )}
      </HvAccordion>
    </div>
  )}
  {ele.plan && ele.plan.Week3 && (
    <div >
      <HvAccordion
        headingLevel={4}
        id="item1"
        label={`${ele.plan.Week3.label} - ${ele.plan.Week3.about}`}
        style={{
          cursor: 'pointer',
          padding: '10px',
          width: '100%',
          border: 'none',
          textAlign: 'left',
          outline: 'none',
          marginLeft:'200px',
        }}
      >
        {ele.plan.Week3.days && Object.keys(ele.plan.Week3.days).map((dayKey)=> (
          <HvAccordion
            headingLevel={4}
            id="item1"
            label={`${ele.plan.Week3.days[dayKey].dLabel} - ${ele.plan.Week3.days[dayKey].name}`}
            style={{
              cursor: 'pointer',
              padding: '10px',
              width: '100%',
              border: 'none',
              textAlign: 'left',
              outline: 'none'
            }}
          >
            <div style={{ paddingLeft: 40 }}>
              <HvListContainer condensed interactive>
                <HvTypography style={{ paddingLeft: 20, fontWeight: 'bold' }}>Details</HvTypography>
                <HvListItem>
                  <a href={'https://www.udemy.com/'} target="_blank" rel="noopener noreferrer">
                    {ele.plan && ele.plan.Week3 && ele.plan.Week3.days && ele.plan.Week3.days[dayKey] && ele.plan.Week3.days[dayKey].details && ele.plan.Week3.days[dayKey].details}
                    
                  </a>
                </HvListItem>
                
                <div style={{ paddingLeft: 40, paddingBottom: 10 }}>
                  {/* <HvListItem startAdornment={<MultiDevices />} style={{ float: 'left' }}>
                    {ele.plan.Week1.days[dayKey] && ele.plan.Week1.days[dayKey].mode && ele.plan.Week1.days[dayKey].mode.length >= 2 && (
                      <>
                        mode - {ele.plan.Week1.days[dayKey].mode[0]} / ele.plan.Week1.days[dayKey].mode[1]}
                      </>
                    )}
                  </HvListItem> */}
                  <HvListItem startAdornment={<MultiDevices />} style={{ float: 'left' }}>
                    {ele.plan.Week3.days[dayKey] && ele.plan.Week3.days[dayKey].mode && ele.plan.Week3.days[dayKey].mode.length >= 2 && (
                      <>
                        mode - {ele.plan.Week3.days[dayKey].mode[0]} / {ele.plan.Week3.days[dayKey].mode[1]}
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<PlayVideo />} style={{ float: 'left' }}>
                    {ele.plan.Week1.days[dayKey] && (
                      <>
                        time - {ele.plan.Week3.days[dayKey].time} mins
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<CompletedStep />}>
                    {ele.plan.Week3.days[dayKey] && ele.plan.Week3.days[dayKey]['prerequisites'] && (
                      <>
                        prerequisites - {ele.plan.Week3.days[dayKey]['prerequisites']}
                      </>
                    )}
                  </HvListItem>
                  <HvListItem startAdornment={<Doc />} style={{}}>
                    {ele.plan.Week3.days[dayKey] && ele.plan.Week3.days[dayKey].references && ele.plan.Week3.days[dayKey].references.length >= 2 && (
                      <>
                        references -
                        <a href={'https://www.udemy.com/'} target="_blank" rel="noopener noreferrer">
                          {ele.plan.Week3.days[dayKey].references[0]}
                        </a>
                        <a href={'https://www.coursera.com/'} target="_blank" rel="noopener noreferrer">
                          {ele.plan.Week3.days[dayKey].references[1]}
                        </a>
                      </>
                    )}
                  </HvListItem>
                </div>
              </HvListContainer>
            </div>
          </HvAccordion>
        )
        )}
      </HvAccordion>
    </div>
  )}
</div>
 </div>
 </div>
 );
 })}
<div className='Footer' style={{ marginTop: 20 }}>
 </div>
 </>
);
};

export default Coursedetails;