import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import {
  HvTableCell,
  //HvTypography,
  HvCheckBox,
  HvTableRow,
  HvTableBody,
  HvTableHeader,
  HvTableHead,
  HvTableContainer,
  HvButton,
  HvInput,
  HvTable,
  HvGlobalActions,
  HvPagination
} from "@hitachivantara/uikit-react-core";
import { Sort } from "@hitachivantara/uikit-react-icons";

export default function CertificateTable() {
  const [certificates, setCertificates] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState("asc");
  //const [selectedSkill, setSelectedSkill] = useState(null);
  // const [newRating, setNewRating] = useState(0);
  // const [newRecentlyUsed, setNewRecentlyUsed] = useState('');

  useEffect(() => {
    axios.get('http://localhost:8080/certificates')
     .then((response) => {
       setCertificates(response.data);
        console.log(response.data);
      })
      .catch((error) => {
         console.error(error);
      });
  }, []);
  const handleSearch = () => {
    axios.get('http://localhost:8080/certificates')
        .then((response) => {
            const filteredCertificates = response.data.filter((certificate) => {
                return certificate.certificate_name.toLowerCase().includes(searchQuery.toLowerCase());
            });
            setCertificates(filteredCertificates);
        })
        .catch((error) => {
            console.error(error);
        });
};
const filteredCertificates = certificates.filter((certificate) =>
    certificate.certificate_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedCertificates = filteredCertificates.sort((a, b) => {
    if (sortOrder === "asc") {
      return a.certificate_name.localeCompare(b.certificate_name);
    } else {
      return b.certificate_name.localeCompare(a.certificate_name);
    }
  });

  const handleSort = () => {
    const newSortOrder = sortOrder === "asc" ? "desc" : "asc";
    setSortOrder(newSortOrder);
  };

  

  return (
      <div className="certificate-table-container" style={{ width: 900 }}>
      <div className="certificate-table">
        <HvGlobalActions title="Certificates" />
        <div style={{ position: 'absolute', top: '75px', right: '60px' }}>
          <Link to="/addCertificate">
            <HvButton variant='primary'>
              Add Certificate
            </HvButton>
          </Link>
        </div>
        <div
  style={{
    height: '20px',
    width:'600px',
    paddingLeft:'300px',
    paddingTop:'10px',
    paddingBottom:'30px'
  }}
>
  <HvInput
    aria-label="Select country"
    onEnter={() => {}}
            placeholder="Search"
            type="search"
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
  />
  </div>
        
        <div style={{ marginTop: "20px" }}>
          <HvTableContainer>
            <HvTable>
              <HvTableHead>
                <HvTableRow>
                  <HvTableCell variant="checkbox" />
                  <HvTableHeader>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <span>CertificateName</span>
                      <Sort
                        style={{
                          fontSize: '12px',
                          color: '#999',
                          cursor: 'pointer',
                          marginLeft: '5px',
                          marginBottom: '2px'
                        }}
                        onClick={handleSort}
                      >
                        {sortOrder === "asc" ? <span>&uarr;</span> : <span>&darr;</span>}
                      </Sort>
                    </div>
                  </HvTableHeader>

                  {/* <HvTableHeader>CertificateName</HvTableHeader> */}
                  <HvTableHeader>Description</HvTableHeader>
                  <HvTableHeader>COP</HvTableHeader>
                  <HvTableHeader>SubCop</HvTableHeader>
                  <HvTableHeader>Vendor</HvTableHeader> 
                </HvTableRow>
              </HvTableHead>
              <HvTableBody>
                {
                  sortedCertificates.map((certificate) => (
                    <HvTableRow key={certificate.certificate_name} hover>
                      <HvTableCell variant="checkbox">
                        <HvCheckBox onClick={() => {}} />
                      </HvTableCell>
                      <HvTableCell>{certificate.certificate_name}</HvTableCell>
                      <HvTableCell>{certificate.description}</HvTableCell>
                      <HvTableCell>{certificate.cop}</HvTableCell>
                      <HvTableCell>{certificate.subcop}</HvTableCell>
                      <HvTableCell>{certificate.vendor}</HvTableCell>
                      
                    </HvTableRow>
                  ))}
              </HvTableBody>
            </HvTable>
          </HvTableContainer>
        </div>
      </div>
      
    </div>
  );
}
