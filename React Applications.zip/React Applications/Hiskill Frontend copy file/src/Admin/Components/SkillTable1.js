import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import {
  HvTableCell,
  HvCheckBox,
  HvTableRow,
  HvTableBody,
  HvTableHeader,
  HvTableHead,
  HvTableContainer,
  HvButton,
  HvInput,
  HvTable,
  HvGlobalActions,
  HvPagination
} from "@hitachivantara/uikit-react-core";
import { Sort } from "@hitachivantara/uikit-react-icons";

export default function SkillTable1() {
  const [skills, setSkills] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState("asc");

  useEffect(() => {
    
    axios.get("api/v1/skillmaster")
          .then((response) => {
            setSkills(response.data);
            console.log(response.data);
          })
          .catch((error) => {
            console.error(error);
          });
  }, []);
  const handleSearch = () => {
    axios.get("api/v1/skillmaster")
        .then((response) => {
            const filteredSkills = response.data.filter((skill) => {
                return skill.skillname.toLowerCase().includes(searchQuery.toLowerCase());
            });
            setSkills(filteredSkills);
        })
        .catch((error) => {
            console.error(error);
        });
};

  const filteredSkills = skills.filter((skill) =>
    skill.skillname.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedSkills = filteredSkills.sort((a, b) => {
    if (sortOrder === "asc") {
      return a.skillname.localeCompare(b.skillname);
    } else {
      return b.skillname.localeCompare(a.skillname);
    }
  });

  const handleSort = () => {
    const newSortOrder = sortOrder === "asc" ? "desc" : "asc";
    setSortOrder(newSortOrder);
  };

  return (
    <div className="skill-table-container" style={{ width: 900 }}>
      <div className="skill-table">
        <HvGlobalActions title="Skills Catalog" />
        <div style={{ position: 'absolute', top: '75px', right: '60px' }}>
          <Link to="/addNewSkill">
            <HvButton variant='primary'>
              Add Skill
            </HvButton>
          </Link>
        </div>
        <div
          style={{
            height: '20px',
            width: '600px',
            paddingLeft: '300px',
            paddingTop: '10px',
            paddingBottom: '30px'
          }}
        >
          <HvInput
            aria-label="Select country"
            onEnter={() => {}}
            placeholder="Search"
            type="search"
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
          />
        </div>
        <div style={{ marginTop: "20px" }}>
          <HvTableContainer>
            <HvTable>
              <HvTableHead>
                <HvTableRow>
                  <HvTableCell variant="checkbox" />
                  <HvTableHeader>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <span>SkillName</span>
                      <Sort
                        style={{
                          fontSize: '12px',
                          color: '#999',
                          cursor: 'pointer',
                          marginLeft: '5px',
                          marginBottom: '2px'
                        }}
                        onClick={handleSort}
                      >
                        {sortOrder === "asc" ? <span>&uarr;</span> : <span>&darr;</span>}
                      </Sort>
                    </div>
                  </HvTableHeader>
                  <HvTableHeader>Version</HvTableHeader>
                  <HvTableHeader>COP</HvTableHeader>
                  <HvTableHeader>SubCop</HvTableHeader>
                  <HvTableHeader>IsDeprecated</HvTableHeader>
                </HvTableRow>
              </HvTableHead>
              <HvTableBody>
                {sortedSkills.map((skill) => (
                  <HvTableRow key={skill.SkillName} hover>
                    <HvTableCell variant="checkbox">
                      <HvCheckBox onClick={() => {}} />
                    </HvTableCell>
                    <HvTableCell>{skill.skillname}</HvTableCell>
                    <HvTableCell>{skill.skillversion}</HvTableCell>
                    <HvTableCell>{skill.cop}</HvTableCell>
                    <HvTableCell>{skill.subcop}</HvTableCell>
                    <HvTableCell>{skill.isdeprecated ? 'True' : 'False'}</HvTableCell>

                  </HvTableRow>
                ))}
              </HvTableBody>
            </HvTable>
          </HvTableContainer>
        </div>
      </div>
      {/* <div className="pagination-container">
        <HvPagination />
      </div> */}
    </div>
  );
}


