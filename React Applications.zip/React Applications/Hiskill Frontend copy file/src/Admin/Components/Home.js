import React from 'react'
import { HvTypography } from "@hitachivantara/uikit-react-core";
export default function Home() {
    return (
        <div
         style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh'
          }}l
        >
          
        <HvTypography
         variant="title1"
            >
              Welcome!!!
            </HvTypography>
        </div>
    )

}