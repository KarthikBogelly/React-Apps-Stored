import React, { useState, version } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router';
import {
  HvCard,
  HvCardContent,
  HvGlobalActions
} from '@hitachivantara/uikit-react-core';
const AddCertificate = ({ onCertificateAdded }) => {
  const navigate = useNavigate();



  const [certificate_name, setCertificateName] = useState('');
  const [CertificateNameError, setCertificateNameError] = useState('');
  const [description, setDescription] = useState();
  const [DescriptionError, setDescriptionError] = useState('');
  const [cop, setCOP] = useState();
  const [COPError, setCOPError] = useState('');
  const [subcop, setSubCop] = useState();
  const [SubCopError, setSubCopError] = useState('');
  const [vendor, setVendor] = useState();
  const [VendorError, setVendorError] = useState('');



  const handleCertificateNameChange = (event) => {
    setCertificateName(event.target.value);
  };
  
  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };


  
  const handleCOPChange = (event) => {
    setCOP(event.target.value);
  };

  const handleSubCopChange = (event) => {
    setSubCop(event.target.value);
  };
  const handleVendorChange = (event) => {
    setVendor(event.target.value);
  };

  

  const handleSubmit =async (event) => {
    event.preventDefault();
    if (validateForm()) {
      const formData = {
        certificate_name,
        description,
        cop,
        subcop,
        vendor
        
        
      };
      
   
      try {
        await axios.post('http://localhost:8080/certificates/post', formData);
        setCertificateName('');
        setDescription('');
        setCOP('');
        setSubCop('');
        setVendor('');
        // onSkillAdded(formData);
        navigate('/certificates'); // Redirect to skill table page
      } catch (error) {
        console.error('Error submitting form:', error);
      }
    }
  };

  const validateForm = () => {
    let isValid = true;

    if (!certificate_name) {
      setCertificateNameError('Certificate Name is required');
      isValid = false;
    } else {
      setCertificateNameError('');
    }

    if (!description) {
      setDescriptionError('Description is required');
      isValid = false;
    } else {
      setDescriptionError('');
    }

    if (!cop) {
      setCOPError('COPis required');
      isValid = false;
    } else {
      setCOPError('');
    }

    if (!subcop) {
      setSubCopError('SubCop is required');
      isValid = false;
    } else {
      setSubCopError('');
    }

    if (!vendor) {
        setVendorError('Vendor is required');
        isValid = false;
      } else {
        setVendorError('');
      }
    

    return isValid;
  };

  const isFormValid = certificate_name && description && cop && subcop && vendor;

  return (
    <>
      <HvGlobalActions
      
        title="Enter the details below"
      >
      </HvGlobalActions>
      <div
        style={{
          margin: 20,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          paddingRight: '50px'
        }}
      >
        <HvCard
          bgcolor="atmo1"
          selectable
          selected
          statusColor="negative"
          style={{ width: 600, padding: '20px', height: '72vh' }}
        >
          <HvCardContent>
            <form onSubmit={handleSubmit}>
              <div
                style={{ marginBottom: '40px', marginTop: '20px', display: 'flex', alignItems: 'center' }}
              >
                <label
                  htmlFor="CertificateName"
                  style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}
                >
                  Certificate Name:
                </label>
                <input
                  type="text"
                  id="CertificateName"
                   value={certificate_name}
                  onChange={handleCertificateNameChange}
                  required
                  style={{
                    width: '200px',
                    padding: '8px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                />
                {CertificateNameError && (
                  <div style={{ color: 'red', marginLeft: '10px' }}>{CertificateNameError}</div>
                )}
              </div>
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="Description" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  Description:
                </label>
                <input
                  type="text"
                  id="Description"
                  value={description}
                  onChange={handleDescriptionChange}
                  required
                  style={{
                    width: '200px',
                    padding: '8px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                />
                {DescriptionError && (
                  <div style={{ color: 'red', marginLeft: '10px' }}>{DescriptionError}</div>
                )}
              </div>
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="COP" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  COP:
                </label>
                <input
                  type="text"
                  id="COP"
                  value={cop}
                  onChange={handleCOPChange}
                  required
                  style={{
                    width: '200px',
                    padding: '8px',
                    borderRadius: '4px',
                    border: '1px solid #ccc',
                  }}
                />
                {COPError && (
                  <div style={{ color: 'red', marginLeft: '10px' }}>{COPError}</div>
                )}
              </div>
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="SubCop" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  SubCop:
                </label>
                <input
                  type="text"
                  id="SubCop"
                  value={subcop}
                  onChange={handleSubCopChange}
                  required
                  style={{
                    width: '200px',
                    padding: '8px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                />
                {SubCopError && (
                  <div style={{ color: 'red', marginLeft: '10px' }}>{SubCopError}</div>
                )}
              </div>
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="Vendor" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  Vendor:
                </label>
                <input
                  type="text"
                  id="Vendor"
                  value={vendor}
                  onChange={handleVendorChange}
                 required
                   style={{
                    width: '200px',
                     padding: '8px',
                     borderRadius: '4px',
                     border: '1px solid #ccc'
                   }}
                />
                {VendorError && (
                  <div style={{ color: 'red', marginLeft: '10px' }}>{VendorError}</div>
                )} 
              </div>
              


              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center',marginTop: '-14px'}}>
              <button
                type="submit"
                style={{
                  backgroundColor: isFormValid ? '#4CAF50' : '#ccc',
                  color: 'white',
                  padding: '8px 20px',

                  border: 'none',
                  borderRadius: '4px',
                  cursor: isFormValid ? 'pointer' : 'not-allowed',
                  fontWeight: 'bold',
                  position: 'relative',
                  top: '-10px',
                  margin: '0 auto'
                  
                }}
                disabled={!isFormValid}
              >
                Submit
              </button>
               </div>
            </form>
          </HvCardContent>
        </HvCard>
      </div>
    </>
  )

}

export default AddCertificate;
