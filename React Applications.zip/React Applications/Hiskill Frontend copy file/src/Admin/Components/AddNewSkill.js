import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import {
  HvCard,
  HvCardContent,
  HvGlobalActions
} from '@hitachivantara/uikit-react-core';

const AddNewSkill = ({ onSkillAdded }) => {
  const navigate = useNavigate();

  const [skillname, setSkillName] = useState('');
  const [SkillNameError, setSkillNameError] = useState('');
  const [skillversion, setSkillVersion] = useState('');
  const [SkillVersionError, setSkillVersionError] = useState('');
  const [cop, setCOP] = useState('');
  const [COPError, setCOPError] = useState('');
  const [subcop, setSubCop] = useState('');
  const [SubCopError, setSubCopError] = useState('');
  const [isdeprecated, setIsDeprecated] = useState('');
  const [IsDeprecatedError, setIsDeprecatedError] = useState('');
 

  const handleSkillNameChange = (event) => {
    setSkillName(event.target.value);
  };

  const handleSkillVersionChange = (event) => {
    setSkillVersion(event.target.value);
  };

  const handleCOPChange = (event) => {
    setCOP(event.target.value);
  };

  const handleSubCopChange = (event) => {
    setSubCop(event.target.value);
  };

  const handleIsDeprecatedChange = (event) => {
    setIsDeprecated(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (validateForm()) {
      const formData = {
        skillname,
        skillversion,
        cop,
        subcop,
        isdeprecated
      };
  
      try {
        await axios.post('api/v1/skillmaster',formData);
        setSkillName('');
        setSkillVersion('');
        setCOP('');
        setSubCop('');
        setIsDeprecated('')
        // onSkillAdded(formData);
        navigate('/skills'); // Redirect to skill table page
      } catch (error) {
        console.error('Error submitting form:', error);
      }
    }
  };
  
  const validateForm = () => {
    let isValid = true;

    if (!skillname) {
      setSkillNameError('Skill Name is required');
      isValid = false;
    } else {
      setSkillNameError('');
    }

    if (!skillversion) {
      setSkillVersionError('Version is required');
      isValid = false;
    } else {
      setSkillVersionError('');
    }

    if (!cop) {
      setCOPError('COP is required');
      isValid = false;
    } else {
      setCOPError('');
    }

    if (!subcop) {
      setSubCopError('SubCop is required');
      isValid = false;
    } else {
      setSubCopError('');
    }

    if (!isdeprecated) {
      setIsDeprecatedError('IsDeprecated is required');
      isValid = false;
    } else {
      setIsDeprecatedError('');
    }

    return isValid;
  };

  const isFormValid = skillname && skillversion && cop && subcop && isdeprecated;

  return (
    <>
      <HvGlobalActions title="Enter the details below" />

      <div style={{ margin: 20, display: 'flex', justifyContent: 'center', alignItems: 'center', paddingRight: '50px' }}>
        <HvCard bgcolor="atmo1" selectable selected statusColor="negative" style={{ width: 600, padding: '20px', height: '72vh' }}>
          <HvCardContent>
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '40px', marginTop: '20px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="skillname" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  Skill Name:
                </label>
                <input
                  type="text"
                  id="SkillName"
                  value={skillname}
                  onChange={handleSkillNameChange}
                  required
                  style={{ width: '200px', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
                {SkillNameError && <div style={{ color: 'red', marginLeft: '10px' }}>{SkillNameError}</div>}
              </div>

              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="Version" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  Version:
                </label>
                <input
                  type="text"
                  id="SkillVersion"
                  value={skillversion}
                  onChange={handleSkillVersionChange}
                  required
                  style={{ width: '200px', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
                {SkillVersionError && <div style={{ color: 'red', marginLeft: '10px' }}>{SkillVersionError}</div>}
              </div>

              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="COP" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  COP:
                </label>
                <input
                  type="text"
                  id="COP"
                  value={cop}
                  onChange={handleCOPChange}
                  required
                  style={{ width: '200px', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
                {COPError && <div style={{ color: 'red', marginLeft: '10px' }}>{COPError}</div>}
              </div>

              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="SubCop" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  SubCop:
                </label>
                <input
                  type="text"
                  id="SubCop"
                  value={subcop}
                  onChange={handleSubCopChange}
                  required
                  style={{ width: '200px', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
                {SubCopError && <div style={{ color: 'red', marginLeft: '10px' }}>{SubCopError}</div>}
              </div>

              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="IsDeprecated" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  IsDeprecated:
                </label>
                <input
                  type="text"
                  id="IsDeprecated"
                  value={isdeprecated}
                  onChange={handleIsDeprecatedChange}
                  required
                  style={{ width: '200px', padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
                />
                {IsDeprecatedError && <div style={{ color: 'red', marginLeft: '10px' }}>{IsDeprecatedError}</div>}
              </div>

              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center',marginTop: '-14px'}}>
              <button
                type="submit"
                style={{
                  backgroundColor: isFormValid ? '#4CAF50' : '#ccc',
                  color: 'white',
                  padding: '8px 20px',

                  border: 'none',
                  borderRadius: '4px',
                  cursor: isFormValid ? 'pointer' : 'not-allowed',
                  fontWeight: 'bold',
                  position: 'relative',
                  top: '-10px',
                  margin: '0 auto'
                  
                }}
                disabled={!isFormValid}
              >
                Submit
              </button>
               </div>
            </form>
          </HvCardContent>
        </HvCard>
      </div>
    </>
  );
};

export default AddNewSkill;


