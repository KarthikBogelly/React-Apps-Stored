import React from 'react';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import EmpRoutes from './Employee/components/EmpRoutes';
import AddSkillDemo from './Employee/components/AddSkillDemo';
function App() {
  return (
    <BrowserRouter>
    <EmpRoutes></EmpRoutes>
    </BrowserRouter>
    // <AddSkillDemo>
    // </AddSkillDemo>
  // <ManagerRoutes></ManagerRoutes>

   )
}

export default App;










