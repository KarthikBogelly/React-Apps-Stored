import React, { useEffect, useState } from 'react';
import './CopDashboard.css';

const CopDashboard = () => {
  const [skills, setSkills] = useState([]);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [employeeData, setEmployeeData] = useState([]);
  const [maxProficiencyLevel, setMaxProficiencyLevel] = useState(0);
  const [gridColors, setGridColors] = useState([]);

  useEffect(() => {
    fetchSkills();
  }, []);

  const fetchSkills = async () => {
    try {
      const response = await fetch('http://13.234.20.12:8080/api/v1/skillmaster');
      const data = await response.json();
      if (Array.isArray(data)) {
        setSkills(data);
        setGridColors(generateGridColors(data.length));
      } else {
        console.log('Skills data is not an array:', data);
      }
    } catch (error) {
      console.log('Error fetching skills:', error);
    }
  };

  const generateDistinctColor = () => {
    const hue = Math.floor(Math.random() * 360); // Random hue value between 0 and 360
    const saturation = Math.floor(Math.random() * 50) + 50; // Random saturation value between 50 and 100
    const lightness = Math.floor(Math.random() * 20) + 40; // Random lightness value between 40 and 60
    return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  };

  const generateGridColors = (length) => {
    const distinctColors = [];

    for (let i = 0; i < length; i++) {
      const color = generateDistinctColor();
      distinctColors.push(color);
    }

    return distinctColors;
  };

  const fetchEmployeeData = async (skillName) => {
    try {
      const response = await fetch(`http://13.234.20.12:8080/api/v1/skillemp/EmpSkill/${skillName}`);
      const data = await response.json();
      const sortedEmployees = data.sort((a, b) => a.proficiencyLevel - b.proficiencyLevel);
      const leastEmployees = sortedEmployees.slice(0, 5);
      setEmployeeData(leastEmployees);
      const proficiencyLevels = leastEmployees.map((employee) => employee.proficiencyLevel);
      const maxLevel = Math.max(...proficiencyLevels);
      setMaxProficiencyLevel(maxLevel);
    } catch (error) {
      console.log(`Error fetching ${skillName} data:`, error);
    }
  };

  const handleSkillClick = async (skillName) => {
    setSelectedSkill(skillName);
    await fetchEmployeeData(skillName);
  };

  const getGridSize = (numEmployees) => {
    if (numEmployees <= 4) {
      return 'grid-item-large';
    } else if (numEmployees <= 8) {
      return 'grid-item-medium';
    } else {
      return 'grid-item-small';
    }
  };

  return (
    <div>
      <h1>Skill Details Heatmap</h1>
      <div className="heatmap">
        {skills.map((skill, index) => {
          let numEmployees = skill.employees?.length || 0;
          let gridSize = getGridSize(numEmployees);
          const gridColor = gridColors[index];

          return (
            <div
              key={skill.skillId}
              className={`heatmap-item ${selectedSkill === skill.skillName ? 'selected' : ''} ${gridSize}`}
              style={{
                backgroundColor: gridColor,
              }}
              onClick={() => handleSkillClick(skill.skillName)}
            >
              {skill.skillName}
            </div>
          );
        })}
      </div>
      {selectedSkill && (
        <div>
          <h2>Selected Skill: {selectedSkill}</h2>
          <table>
            <thead>
              <tr>
                <th>Employee Name</th>
                <th>Proficiency Level</th>
              </tr>
            </thead>
            <tbody>
              {employeeData.map((employee) => (
                <tr key={employee.empId}>
                  <td>{employee.empName}</td>
                  <td>{employee.proficiencyLevel}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default CopDashboard;
