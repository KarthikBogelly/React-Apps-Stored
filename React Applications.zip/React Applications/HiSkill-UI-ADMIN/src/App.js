import React from 'react';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import './App.css';
import Sidebar from './component/Sidebar';
import Home from './component/Home';
import SkillList from './component/SkillList';
import AddSkill from './component/AddSkill';
import CertificateList from './component/CertificateList';

function App() {
  return (
    <Router>
      <div className="app-container">
        <div className="sidebar-container">
          <Sidebar />
        </div>
        <div className="applist-container">
          <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="/skillList" element={<SkillList />} />
            <Route path="/homepage" element={<Home/>} />
            <Route path="/addSkill" element={<AddSkill/>} />
            <Route path="/certificateList" element={<CertificateList/>} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;



