import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { faPlusCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './SkillList.css'; 

const SkillList = () => {

    const [skills, setSkills] = useState([]);

    useEffect(() => {
        axios.get("/api/v1/skillset")
          .then((response) => {
            setSkills(response.data);
            console.log(response.data);
          })
          .catch((error) => {
            console.error(error);
          });
    }, []);

    return (
        <div>
            <hr style={{height:"2px",borderWidth:"0",color:"gray",backgroundColor:"grey"}}></hr>
            <h1 className="display-5 fw-bold text-center" style={{color: "#333333"}}>Skills Catalog</h1>
            <hr style={{height:"2px",borderWidth:"0",color:"gray",backgroundColor:"grey"}}></hr>
            <div className="row row-cols-1 row-cols-md-3 g-4 mx-3 mt-3">
                {
                    skills && skills.map((skill) => (
                        <div key={skill.skillId} className="col">
                            <div className="card skill-card" style={{cursor:"pointer"}}>
                                <div className="card-header">
                                    <h5 className="display-7 col d-flex justify-content-center mt-1">{skill.skillname}</h5>                             
                                </div>
                                <div className="card-body">
                                    <p className="card-text"><b>ID: </b>{skill.skillId}</p>
                                    <p className="card-text"><b>COP: </b>{skill.cop}</p>
                                    <p className="card-text"><b>SUBCOP: </b>{skill.subcop}</p>
                                    <p className="card-text"><b>VERSION: </b>{skill.version}</p>
                                    <p className="card-text"><b>IS DEPRECATED: </b>{skill.isdepricted ? "true" : "false"}</p>
                                </div>                               
                            </div>
                        </div>
                    ))
                }                
            </div>
            <div className="d-flex justify-content-center mt-5 mb-5">
                <Link to="/addSkill">
                    <button type="button" className="btn btn-primary btn-lg">
                        <FontAwesomeIcon className="mx-2" icon={faPlusCircle}></FontAwesomeIcon>
                        Add New Skill
                    </button>
                </Link>
            </div>
        </div>
    );
}

export default SkillList;
