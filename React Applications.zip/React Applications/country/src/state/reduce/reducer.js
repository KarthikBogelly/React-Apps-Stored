const Initial_State =
{
    countryName:[],
    selectedContinent:'Africa',
    searchResult:" ",
    isLoading:false
};
export const reducer=(state=Initial_State,action)=>
{
    switch(action.type)
    {
        case 'SET_COUNTRY_NAME':
            return {...state,countryName:action.payload};
        case 'SET_SELECTED_CONTINENT':
            return{...state,selectedContinent:action.payload};
        case 'SET_SEARCH_RESULT':
            return {...state,searchResult:action.payload};
        case 'SET_IS_LOADING':
            return {...state,isLoading:action.payload};
        default:
            return state;    
        }
}
