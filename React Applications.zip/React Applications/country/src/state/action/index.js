export const setSelectedContinent=(result)=>
{
    return dispatch=>
    dispatch
    ({
        type:'SET_SELECTED_CONTINENT',
        payload:result
    })
}
export const setCountryName=(result)=>
{
    return dispatch=>
    dispatch
    ({
        type:'SET_COUNTRY_NAME',
        payload:result
    })
}
export const setSearchResult=(result)=>
{
    return dispatch=>
    dispatch
    ({
        type:'SET_SEARCH_RESULT',
        payload:result
    })
}
export const setIsLoading=(result)=>
{
    return dispatch=>
    dispatch
    ({
        type:'SET_IS_LOADING',
        payload:result
    })
}
