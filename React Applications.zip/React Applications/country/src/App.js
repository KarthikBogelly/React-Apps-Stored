import './App.css';
import Dropdown from './component/Dropdown';

function App() {
  return (
    <center>
     <div className='mx-5'
        style=
        {{
          backgroundColor: 'lightgoldenrodyellow'
        }}
      >
        <Dropdown />
      </div>
    </center>
  );
}

export default App;
