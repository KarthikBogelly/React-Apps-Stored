import './App.css';
import MainPage from './components/MainPage';

function App() {
  return (
    <center>
     <div className='background-image mx-5' >
        <MainPage />
      </div>
    </center>
  );
}

export default App;
