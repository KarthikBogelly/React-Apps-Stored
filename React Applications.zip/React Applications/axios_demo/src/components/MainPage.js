import React from 'react'
import {useState, useEffect} from 'react'
import axios from 'axios';
export default function Dropdown() {
    
    const continent = ["Africa", "Americas", "Asia", "Europe", "Oceania"];
    const [countryName, setCountryName] = useState([]);
    const [selectedContinent, setSelectedContinent ] = useState("Africa");
    const [searchResult,setSearchResult] = useState("");
    //const [isSearchResult,setIsSearchResult] = useState(false);
    const [isLoading,setIsLoading] = useState(false);

    const handleChange = (event) => 
    {
        console.log(event.target.value);
        setSelectedContinent(event.target.value);
       
        setSearchResult("");
    }



    const handleChangeSearch=(event) =>
    {
        setSearchResult(event.target.value);
    }

   



useEffect(() => 
{
    setIsLoading(true);
    
   setTimeout(() =>
   axios.get('https://restcountries.com/v2/region/'+selectedContinent)
   .then(function (response)
   {
     
     console.log(response);
     setCountryName(response);
     setIsLoading(false);
   }
   )
   .catch(function (error) 
   {
      console.log(error);
   }
   ),1000
   )
},[selectedContinent])

const filteredCountries = countryName.data && countryName.data.filter((country) =>
  country.name.toLowerCase().includes(searchResult.toLowerCase())
);


  return (
    <>
        <div>
            <h1 className='card-title'>Continents and Countries</h1>
            <nav className="navbar navbar-expand-lg bg-body" style={{paddingTop: "0px",paddingBottom: "0px"}}>
                <div className="container-fluid" style={{backgroundColor:""}}>
                    <select className="form-select mx-5"
                     aria-label="Default select example"
                     value={selectedContinent}
                     onChange={handleChange} >
                        {
                            continent.map((continent,index) => (
                            <option key={index} value={continent}>
                                {continent}
                                </option>

                            ))
                        }
                    </select>
                    <form className="d-flex my-3" role="search"  >
                        <input className="form-control me-2" 
                        type="search" 
                        placeholder="Search" 
                        aria-label="Search" 
                        onChange={handleChangeSearch}
                        value={searchResult}
                        />
                       
                    </form>
                    </div>
            </nav>
            {
                (countryName.data)?<div className="row row-cols-1 row-cols my-3 g-4 m-5">
                {
                   !isLoading?filteredCountries.length!==0?(filteredCountries.map((element)=>{
                        return (
                        <>
                            <div className="card  my-3 mx-3" style={{width:"502px",height:"200px"}}>
                                <div className="row g-0">
                                    <div className="col-md-4">
                                        <img src={element.flag} className="img-fluid mx-3 my-5 " alt="..."/>
                                    </div>
                                    <div className="col-md-8">
                                        <div className="card-body">
                                            <h5 className="card-title">{element.name}</h5>
                                            <h6 className="card-subtitle mb-2 text-muted">Capital : {element.capital}</h6>
                                            <p className="card-text">Time-Zone : {element.timezones}</p>
                                            <p className="card-text">Population : {element.population}</p>
                                            <p className="card-text">CIOC : {element.cioc}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>
                    
                        )
                    })
                    ): <div className="alert alert-danger" role="alert">
                             Enter the correct country name !!!
                        </div>
                   
                    :<left>
                        <div className="d-flex justify-content-center">
                            <div className="spinner-grow text-muted mt-5"></div>
                            <div className="spinner-grow text-primary mt-5"></div>
                            <div className="spinner-grow text-success mt-5"></div>
                            <div className="spinner-grow text-info mt-5"></div>
                            <div className="spinner-grow text-warning mt-5"></div>
                            <div className="spinner-grow text-danger mt-5"></div>
                            <div className="spinner-grow text-secondary mt-5"></div>
                            <div className="spinner-grow text-dark mt-5"></div>
                            <div className="spinner-grow text-light mt-5"></div>
                        </div>
                    </left>

                }
                </div>
                :  <div className="card p-5 mt-5">
                        <div className="alert alert-success" role="alert">
                            Wait until the page is loaded !!!
                        </div>
                    </div>
            }

        </div>
    </>
  )
}
