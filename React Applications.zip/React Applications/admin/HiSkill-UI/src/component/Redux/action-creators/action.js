export const SetValue=(result)=>{
    return (dispatch)=>{
        dispatch({
            type:'EmployeeRating',
            payload:result
        })
    }
}
export const SetValue1=(result)=>{
    return (dispatch)=>{
        dispatch({
            type:'EmployeeCOPRating',
            payload:result
        })
    }
}