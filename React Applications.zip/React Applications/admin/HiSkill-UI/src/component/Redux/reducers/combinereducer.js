import {combineReducers} from 'redux'
import reducer from './reducer'


const reducers=combineReducers({
    combined:reducer
})

export default reducers