const Intitial_State={
    Value:[
      //   {
      //     "id": 1,
      //     "empId": "HV121",
      //     "empName": "Vishruth",
      //     "skillObj": 
      //     [
      //       {
      //         "skill": 'Java',
      //         "rating": '3',
      //         "experience": "10"
      //       },
      //       {
      //         "skill": 'C++',
      //         "rating": '4',
      //         "experience": "4"
              
      //       },
      //       {
      //         "skill": 'C',
      //         "rating": '2',
      //         "experience": "2"
      //       },
      //       {
      //         "skill": 'Python',
      //         "rating": '2',
      //         "experience": "5"
              
      //       },
      //       {
      //         "skill": 'Perl',
      //         "rating": '3',
      //         "experience": "8"
      //       }
      //     ],
      // },
      // {
      //   "id": 2,
      //   "empId": "HV122",
      //   "empName": "Valandas",
      //   "skillObj": 
      //   [
      //     {
      //       "skill": 'C++',
      //       "rating": '5',
      //       "experience": "10"
      //     },
      //     {
      //       "skill": 'Java',
      //       "rating": '5',
      //       "experience": "4"
            
      //     },
      //     {
      //       "skill": 'Python',
      //       "rating": '3',
      //       "experience": "2"
      //     },
      //     {
      //       "skill": 'Perl',
      //       "rating": '5',
      //       "experience": "5"
            
      //     },
      //     {
      //       "skill": 'Cobol',
      //       "rating": '5',
      //       "experience": "8"
      //     }
      //   ],
      // },
      // {
      //   "id": 3,
      //   "empId": "HV123",
      //   "empName": "Shashank",
      //   "skillObj": 
      //   [
      //     {
      //       "skill": 'C++',
      //       "rating": '5',
      //       "experience": "10"
      //     },
      //     {
      //       "skill": 'Java',
      //       "rating": '5',
      //       "experience": "4"
            
      //     },
      //     {
      //       "skill": 'Python',
      //       "rating": '3',
      //       "experience": "2"
      //     },
      //     {
      //       "skill": 'Perl',
      //       "rating": '5',
      //       "experience": "5"
            
      //     },
      //     {
      //       "skill": 'Cobol',
      //       "rating": '5',
      //       "experience": "8"
      //     }
      //   ],
      // },
      ],
      COPValue:[]
};

const reducer=(state=Intitial_State,action)=>{
    if(action.type==='EmployeeRating'){
        return {...state,Value:action.payload}
    }
    else if(action.type==='EmployeeCOPRating'){
        return {...state,COPValue:action.payload}
    }
    else{
        return state;
    }
}
export default reducer