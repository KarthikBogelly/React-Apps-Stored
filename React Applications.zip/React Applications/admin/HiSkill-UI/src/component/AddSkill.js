import axios from 'axios';
import React, { useState } from 'react';
import Spinner from './Spinner';
import { useNavigate } from 'react-router-dom';

const AddSkill = () => {
    const navigate = useNavigate();

    const [formValue, setFormValue] = useState({
        skillId: "",
        skillname: "",
        cop: "",
        subcop: "",
        version: "",
        isdepricted: false
    });

    const [isLoading, setIsLoading] = useState(false);
    const [formErrors, setFormErrors] = useState({
        skillId: false,
        skillname: false,
        cop: false,
        subcop: false,
        version: false
    });

    const handleSubmit = async (event) => {
        event.preventDefault();
        const hasErrors = validateForm();
        if (!hasErrors) {
            setIsLoading(true);
            const formData = new FormData();
            formData.append("skillId", formValue.skillId);
            formData.append("skillname", formValue.skillname);
            formData.append("cop", formValue.cop);
            formData.append("subcop", formValue.subcop);
            formData.append("version", formValue.version);
            formData.append("isdepricted", formValue.isdepricted);

            try {
                await axios(
                    {
                        method: "post",
                        url: "/skillset",
                        data: formData,
                        headers: { "Content-Type": "application/json" },
                    })
                setIsLoading(false);
                navigate('/skillList');
            }
            catch (error) {
                console.log(error)
                setIsLoading(false);
            }
        }
    }

    const handleChange = (event) => {
        setFormValue({
            ...formValue,
            [event.target.name]: event.target.value
        });
        setFormErrors({
            ...formErrors,
            [event.target.name]: false
        });
    }

    const validateForm = () => {
        let hasErrors = false;
        const errors = {
            skillId: false,
            skillname: false,
            cop: false,
            subcop: false,
            version: false
        };
        for (const key in formValue) {
            if (formValue.hasOwnProperty(key) && formValue[key] === "") {
                hasErrors = true;
                errors[key] = true;
            }
        }
        setFormErrors(errors);
        return hasErrors;
    }

    return (
        <div className="container mt-3">
            <div className="row justify-content-center">
                <div className="col-md-8">
                    <div className="card">
                        <div className="card-header bg-tertiary text-black">
                            <h1 className="card-title text-center mb-0">Add New Skill</h1>
                        </div>
                        <div className="card-body">
                            <form onSubmit={handleSubmit} onClick=()>
                                <div className="form-group">
                                    <label htmlFor="skillId">Skill ID</label>
                                    <input type="text" name="skillId" onChange={handleChange} value={formValue.skillId} placeholder="Enter the skill ID here" className={`form-control ${formErrors.skillId ? 'is-invalid' : ''} mb-2`} id="skillId" />
                                    {formErrors.skillId && (
                                        <div className="invalid-feedback">
                                            Skill ID is required
                                        </div>
                                    )}
                                </div>
                                <div className="form-group">
                                    <label htmlFor="skillname">Skill Name</label>
                                    <input type="text" name="skillname" onChange={handleChange} value ={formValue.skillname} placeholder="Enter the skill name here"  className={`form-control ${formErrors.skillname ? 'is-invalid' : ''} mb-2`} id="skillname" />
                                    {formErrors.skillname && (
                                    <div className="invalid-feedback">
                                    Skill name is required
                                    </div>
                                    )}
                                </div>
                                    <div className="form-group">
                                        <label htmlFor="cop">COP</label>
                                        <input type="text" name="cop" onChange={handleChange} value={formValue.cop} placeholder="Enter the COP here"  className={`form-control ${formErrors.cop ? 'is-invalid' : ''} mb-2`} id="cop" />
                                        {formErrors.cop && (
                                        <div className="invalid-feedback">
                                        COP is required
                                        </div>
                                        )}
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="subcop">SubCOP</label>
                                        <input type="text" name="subcop" onChange={handleChange} value={formValue.subcop} placeholder="Enter the SubCOP here"  className={`form-control ${formErrors.subcop ? 'is-invalid' : ''} mb-2`} id="subcop" />
                                        {formErrors.subcop && (
                                        <div className="invalid-feedback">
                                        SubCOP is required
                                        </div>
                                        )}
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="version">Version</label>
                                        <input type="text" name="version" onChange={handleChange} value={formValue.version} placeholder="Enter the version here"  className={`form-control ${formErrors.version ? 'is-invalid' : ''} mb-2` } id="version" />
                                        {formErrors.version && (
                                        <div className="invalid-feedback">
                                        Version is required
                                        </div>
                                        )}
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="isdepricted">Is Deprecated?</label>
                                        <select name="isdepricted" onChange={handleChange} value={formValue.isdepricted} className="form-control" style={{cursor:"pointer"}} id="isdepricted">
                                        <option value={false}>No</option>
                                        <option value={true}>Yes</option>
                                    </select>
                                    </div>
                                    <div className="text-center">
                                        <button type="submit" onClick={()=>navigate('/skill')} className="btn btn-primary mt-3">{isLoading ? <Spinner /> : 'Submit'}</button>
                                    </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        );
     };
export default AddSkill;
