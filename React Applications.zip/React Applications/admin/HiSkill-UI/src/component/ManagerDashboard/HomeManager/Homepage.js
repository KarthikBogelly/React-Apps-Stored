import React from 'react'

export default function Homepage() {
  return (
    <div><div class="px-4 py-5 my-5 text-center">
    <h1 class="display-5 fw-bold text-body-emphasis">HiSkill</h1>
    <hr/>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4">Hiskill enables to an employee add their skills.</p>
    </div>
  </div>
  </div>
  )
}
