import React from 'react'

import SideComponent from '../SideComponent/SideComponent'
import Homepage from './Homepage'

export default function HomeManager() {
  return (
    <div>
      <div className="row" style={{marginRight:"0px"}}>
      
        <div className="col-4 col-md-4"><SideComponent/></div>
        <div className="col-14 col-md-6" style={{height:"100vh"}}><Homepage/></div>
        
        {/* <div className="col-md-8"><Test/></div> */}
      </div>
    </div>
  )
}