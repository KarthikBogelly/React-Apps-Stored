import React from 'react'

export default function Loader() {
  return (
    <div><div className="d-flex justify-content-center m-5">
    <div className="spinner-grow text-primary" role="status" style={{animationDelay: "-3s"}}>
        <span className="visually-hidden">Loading...</span>
    </div>
    <div className="spinner-grow text-secondary" role="status" style={{animationDelay: "-2.5s"}}>
    <span className="visually-hidden">Loading...</span>
    </div>
    <div className="spinner-grow text-success" role="status" style={{animationDelay: "-2s"}}>
        <span className="visually-hidden">Loading...</span>
    </div>
    <div className="spinner-grow text-danger" role="status" style={{animationDelay: "-1.5s"}}>
        <span className="visually-hidden">Loading...</span>
    </div>
    <div className="spinner-grow text-warning" role="status" style={{animationDelay: "-1s"}}>
        <span className="visually-hidden">Loading...</span>
    </div>
    <div className="spinner-grow text-info" role="status" style={{animationDelay: "-0.5s"}}>
        <span className="visually-hidden">Loading...</span>
    </div>
</div></div>
  )
}
