import React from 'react'
import { Link } from 'react-router-dom'

export default function SideComponent() {
  // const [loading,setloading]=useState(true);
  // const onloaderHandler=()=>{
  //   console.log("Hello");
  // }
  return (
    <div className="position-fixed">
      <div className="d-flex flex-column flex-shrink-0 p-3 bg-body-tertiary" style={{width: "280px",height:"100vh"}}>
      <svg className="bi pe-none me-2" width="40" height="32"></svg>
      <span className="fs-4"><h2>HiSkill</h2></span>
    <hr/>
    <ul className="nav nav-pills flex-column mb-auto">
      <li className="nav-item">
        <Link to="/ManagerHome" className="nav-link link-body-emphasis" aria-current="page">
        <div className="d-flex justify-content-start">
          <div>
        <lord-icon
            src="https://cdn.lordicon.com/osuxyevn.json"
            trigger="loop-on-hover"
            delay="1000"
            style={{width:"30px",height:"30px"}}>
        </lord-icon>
        </div>
        <div>Home</div>
        </div>
        </Link>
      </li>
      <li className="nav-item">
        <Link to="/ManagerDashboard" className="nav-link link-body-emphasis" aria-current="page">
        <div className="d-flex justify-content-start">
          <div>
          <lord-icon
            src="https://cdn.lordicon.com/eliwatfs.json"
            trigger="loop-on-hover"
            delay="1000"
            colors="primary:#121331"
            scale="45"
            style={{width:"30px",height:"30px"}}>
        </lord-icon>
          </div>
          <div>
          Dashboard
          </div>
        </div>
        
        </Link>
      </li>
      <li>
        <Link to="/employeeDetails" className="nav-link link-body-emphasis">
          <div className="d-flex align-items-start">
          <lord-icon
            src="https://cdn.lordicon.com/dxjqoygy.json"
            trigger="loop-on-hover"
            delay="2000"
            colors="primary:#121331,secondary:#000000"
            stroke="100"
            style={{width:"30px",height:"30px"}}>
        </lord-icon>
        <div>
        Employee Details
        </div>
          </div>
        </Link>
      </li>
    </ul>
    <hr/>
    <div className="dropdown">
      <a href="/" className="d-flex align-items-center link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
        <i width="32" height="32" className="fas fa-user-circle rounded-circle me-2"></i>
        {/* <img src="https://github.com/mdo.png" alt="" width="32" height="32" className="rounded-circle me-2"/> */}
        <strong>#User</strong>
      </a>
      <ul className="dropdown-menu text-small shadow">
        <li><a className="dropdown-item" href="/">Sign out</a></li>
      </ul>
    </div>
  </div>
    </div>
  )
}
