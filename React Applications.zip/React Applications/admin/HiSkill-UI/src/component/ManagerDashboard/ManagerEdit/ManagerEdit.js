import { Slider, ThemeProvider,createTheme } from '@mui/material';
import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom';
import {actionCreators} from '../../Redux/allaction'
import {skills} from '../Skill'
import {emoji} from '../Emoji'


export default function ManagerEdit() {
    const [EmpDetails,setEmpDetails]=useState();
    const{name,skill}=useParams();
    const [textboxes, setTextboxes] = useState({
      field:"",
      rating:1
    });
    const hello1=useSelector(state=>state.combined)
    const dispatch=useDispatch();
    
    useEffect(()=>{
        console.log(name+" "+skill);
        const EmployeeDetails=hello1.Value&&hello1.Value.filter((element)=>{
            return element.empName===name;
        })
        // console.log(EmployeeDetails[0]);
        setEmpDetails(EmployeeDetails[0]);

    },[])
    const onchangeslider=(value)=>{
      setTextboxes({field:skill,rating:value})
      console.log({field:skill,rating:value})
    }
    const muiTheme = createTheme({
      overrides:{
        MuiSlider: {
          thumb:{
          color: "yellow",
          },
          track: {
            color: 'red'
          },
          rail: {
            color: 'black'
          }
        }
    }
    });
    const onclickHandler=(event)=>{
      event.preventDefault();
      // const filteredEmployees=Value&&Value.filter((element)=>{
      //   return element.name!==name;
      // })
      const New=EmpDetails&&EmpDetails.skillObj.map((element)=>{
        if(element.skill===skill){
          return {...element,
            rating:textboxes.rating.toString()};
        }
        
        return element;
      })
      console.log(New);
      setEmpDetails({empName:name,skillObj:New});
      const filteredEmployees=hello1.Value&&hello1.Value.map((element)=>{
        if(element.empName===name){
          return {...element,
            skillObj:New};
        }
        return element;
      })
      dispatch(actionCreators.SetValue(filteredEmployees));
      // // setValue(filteredEmployees);
      // // setValue(c);
      // console.log(filteredEmployees);
      
    }
     
  return (
    <div>

        {(window.location.pathname===`/labels/employeeedit/${name}/${skill}`)?<Link to={`/labels/${skill}`}>
        <button class="btn btn-primary" type="submit">Back</button>
        </Link>:<Link to={`/employeeDetails/${name}`}>
        <button class="btn btn-primary" type="submit">Back</button>
        </Link>}

        
        
        {
            EmpDetails&&EmpDetails.skillObj.map((element)=>{
                return(
                    (element.skill===skill)?<div className="px-4 py-5 my-5 text-center">
                    <img className="d-block mx-auto mb-4" src={skills[element.skill]} alt="" width="72" height="57"/>
                    <h1 className="display-5 fw-bold text-body-emphasis">{EmpDetails.empName}</h1>
                    <div className="col-lg-6 mx-auto">
                      <div><h4>previous Rating</h4>{emoji[element.rating]}</div>
                      <div><h4>Change Rating</h4></div>
                      <div style={{display: 'flex',justifyContent: "space-between"}}>{emoji[textboxes.rating]}</div>
                            {/* <div style={{width:"100px"}}> */}
                            <ThemeProvider theme={muiTheme} width="100px">
                                        <Slider
                                          defaultValue={1}
                                          step={1}
                                          marks
                                          min={1}
                                          max={5}
                                          onChange={(event)=>{onchangeslider(event.target.value)}}
                                        />
                                        </ThemeProvider>
                                        {/* </div> */}
                      <div className="d-grid gap-2 d-sm-flex justify-content-sm-center">
                        <button type="button" className="btn btn-primary btn-lg px-4 gap-3" onClick={onclickHandler}>Submit</button>
                      </div>
                    </div>
                  </div>:null
                )
            })
        }
    </div>
  )
}
