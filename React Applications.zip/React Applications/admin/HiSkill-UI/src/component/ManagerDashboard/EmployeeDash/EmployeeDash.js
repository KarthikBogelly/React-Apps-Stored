import React from 'react'

import ManagerDashboard from '../EmployeeDashboard/ManagerDashboard'
import COPManagerDashboard from '../EmployeeCOPDashboard/ManagerDashboard'
import { useState } from 'react';
export default function EmployeeDash() {
    const [showComponent, setShowComponent] = useState(true);
  const [buttonClicked, setButtonClicked] = useState(1);

  // Your button click handlers
  const handleButton1Click = () => {
    setShowComponent(true);
    setButtonClicked(1);
  };
  
  const handleButton2Click = () => {
    setShowComponent(true);
    setButtonClicked(2);
  };
  return (
    <div>
        <div class="d-inline-flex gap-2 mb-5 my-5">
            <button class="d-inline-flex align-items-center btn btn-primary btn-lg px-4 rounded-pill" type="button" onClick={handleButton1Click}>
                EmployeeSkillDashboard
            </button>
            <button class="btn btn-outline-secondary btn-lg px-4 rounded-pill" type="button" onClick={handleButton2Click}>
                COPDashboard
            </button>
        </div>
      {showComponent && buttonClicked === 1 && <ManagerDashboard />}
      {showComponent && buttonClicked === 2 && <COPManagerDashboard />}
    </div>
  )
}
