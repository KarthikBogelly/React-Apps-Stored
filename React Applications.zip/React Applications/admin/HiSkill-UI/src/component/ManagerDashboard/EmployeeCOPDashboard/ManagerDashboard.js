
import React, { useState, useEffect } from 'react';
import Chart from 'chart.js/auto';
import { CategoryScale } from 'chart.js';
import PieChart1 from './Piechart/PieChart1';
import { useDispatch, useSelector } from 'react-redux';
import { actionCreators } from '../../Redux/allaction';
import Loader from '../Loader/Loader'

Chart.register(CategoryScale);

export default function ManagerDashboard() {
  const [SkillsSet, setSkillSet] = useState([]);
  const [label, setLabel] = useState([]);
  const [chartData, setChartData] = useState();
  const hello=useDispatch();
  const hello1=useSelector(state=>state.combined);
  const [Employee, setEmployee] = useState([]);

 

  useEffect(() => {
    
    getUnique();
  }, []);
  // async function getElement() {
  //   const response = await fetch("/data");
  //   const jsonData = await response.json();
  //   setEmployee(jsonData);
  //   console.log(Employee);
  //   // console.log(jsonData);
  // }
//   const getUnique = () => {
//     const newValues = {};
//     hello1.Value.forEach((element) => {
//       element.ratings.forEach((element1) => {
//         if (newValues.hasOwnProperty(element1.field)) {
//           newValues[element1.field]++;
//         } else {
//           newValues[element1.field] = 1;
//         }
//       });
//     });

//     setSkillSet(newValues);

//     const labelData = [];
//     for (const key in newValues) {
//       labelData.push({
//         skill: key,
//         number: newValues[key],
//       });
//     }
//     setLabel(labelData);

//     setChartData({
//       labels: labelData.map((element) => element.skill),
//       datasets: [
//         {
//           label: 'Number of employees having skill',
//           data: labelData.map((element) => element.number),
//           backgroundColor: [
//             'rgb(255, 99, 132)',
//             'rgb(54, 162, 235)',
//             'rgb(255, 205, 86)',
//           ],
//           hoverOffset: 30,
//         },
//       ],
//     });
//   };

//   return (
//     <div>
//       <div style={{width:"500px",height:"500px"}}>
//         {SkillsSet.length !== 0 ? (
//           <PieChart1 chartData={chartData}/>
//         ) : (
//           'Hello'
//         )}
//       </div>
//     </div>
//   );
// }

async function getUnique () {
  const response = await fetch("/skillgap");
    const jsonData = await response.json();
    setEmployee(jsonData);
    // console.log(Employee);
    // console.log(jsonData);
    hello(actionCreators.SetValue1(jsonData));
    const newValues = {};
    jsonData&&jsonData.forEach((element) => {
      // console.log(element);
      element.skillObj1.forEach((element1) => {
        if (newValues.hasOwnProperty(element1.skill)) {
          newValues[element1.skill]++;
        } else {
          newValues[element1.skill] = 1;
        }
    });
    });

  setSkillSet(newValues);

  const labelData = [];
  for (const key in newValues) {
    labelData.push({
      skill: key,
      number: newValues[key],
    });
  }
  setLabel(labelData);

  setChartData({
    labels: labelData.map((element) => element.skill),
    datasets: [
      {
        label: 'Number of employees having COP',
        data: labelData.map((element) => element.number),
        backgroundColor: [
          'rgb(255, 99, 132)',
          'rgb(54, 162, 235)',
          'rgb(255, 205, 86)',
        ],
        hoverOffset: 30,
      },
    ],
  });
};

return (
  <div>
    <div style={{width:"500px",height:"500px"}}>
      {SkillsSet.length !== 0 ? (
        <PieChart1 chartData={chartData}/>
      ) : (
        <Loader/>
      )}
    </div>
  </div>
);
}