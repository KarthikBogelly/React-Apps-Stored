import React from 'react'
import SideComponent from '../SideComponent/SideComponent'
import NotFound from './NotFound'

export default function NotfoundDash() {
  return (
    <div>
      <div className="row" style={{marginRight:"0px"}}>
      
        <div className="col-4 col-md-4"><SideComponent/></div>
        <div className="col-14 col-md-6" style={{height:"100vh"}}><NotFound/></div>
      </div>
    </div>
  )
}
