import React from 'react'
import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div>
      <div class="px-4 py-5 my-4 text-center">
      <lord-icon
    src="https://cdn.lordicon.com/hrqwmuhr.json"
    trigger="loop-on-hover"
    delay="500"
    style={{width:"250px",height:"250px"}}>
</lord-icon>
    <h1 class="display-1 fw-bold text-body-emphasis" style={{fontFamily: "'Sofia Sans Condensed', sans-serif"}}>404</h1>
    <div class="col-lg-6 mx-auto">
    <h2 style={{fontFamily: "'Sofia Sans Condensed', sans-serif"}}>Page Not Found</h2>
      <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
        <Link to="/ManagerHome">
        <button type="button" class="btn btn-outline-secondary btn-lg px-4 my-3">Home</button>
        </Link>
      </div>
    </div>
  </div>
    </div>
  )
}
