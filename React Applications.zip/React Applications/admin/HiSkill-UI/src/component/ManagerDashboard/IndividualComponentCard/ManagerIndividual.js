import React, { useState } from 'react'
import "./css/card.css"
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import {skills} from '../Skill'

export default function ManagerIndividual() {
    const [input,setinput]=useState("");
    const [employeeName,setemployeeName]=useState("");
    const [COPemployeeName,setCOPemployeeName]=useState([]);
    const hello1=useSelector(state=>state.combined)
    const onchangeHandler=(event)=>{
        // console.log(event.target.value);
        setinput(event.target.value);
        const Hello=hello1.Value&&hello1.Value.filter((element,index)=>{
            return element.empName.toLowerCase().indexOf((event.target.value).toLowerCase())!==-1;
        });
        setemployeeName(Hello);
        const COPValu=hello1.COPValue&&hello1.COPValue.filter((element,index)=>{
          return element.empName.toLowerCase().indexOf((event.target.value).toLowerCase())!==-1;
      });
      // console.log(COPValu);
      setCOPemployeeName(COPValu);

    }
    return (
        <div>

            <div className="p-3 pb-md-4 mx-auto text-center" style={{marginTop:"30px"}}>
                <h3 className="m-4">Employee Details</h3>
                <input className="form-control" id="exampleDataList" placeholder="Enter Employee Name" value={input} onChange={onchangeHandler}/>
            </div>
            <div >
            <div className="row row-cols-1 row-cols-md-3 g-4">  
              <div className="container1">
                              {
                              
                              employeeName?employeeName.map((element)=>{
                                
                                const correspondingCOPemployee = COPemployeeName.find(emp => emp.empName===element.empName);
                                // console.log(correspondingCOPemployee);
                                  return(
                                  <div className="col">
                                  <div className="card1">
                                    <div className="face face1">
                                    <div className="content">
                                      
                                      <h3 style={{fontFamily: "'Acme', sans-serif"}}>{element.empName}</h3>
                                    </div>
                                  </div>
                                  <div className="face face2">
                                    <div className="content">
                                      <h6>Skills: {element.skillObj.length}</h6>
                                      <h6>COP: {correspondingCOPemployee?correspondingCOPemployee.skillObj1.length:"NO COPs Found"}</h6>
                                      <Link to={`/employeedetails/${element.empName}`}>
                                      <lord-icon
                                          src="https://cdn.lordicon.com/xhwleznj.json"
                                          trigger="loop-on-hover"
                                          delay="1000"
                                          style={{width:"50px",height:"50px"}}>
                                      </lord-icon>
                                      </Link>
                                      {/* <a href="/">Read More</a> */}
                                    </div>
                                  </div>
                                  </div>
                                  </div>
                                  
                                  )
                              }):hello1.Value&&hello1.Value.map((element)=>{
                                // console.log(hello1.COPValue);
                                const correspondingCOPemployee = hello1.COPValue.find(emp => emp.empName===element.empName);
                                // console.log(correspondingCOPemployee);
                                return(
                                  <div className="col">
                                  <div className="card1">
                                    <div className="face face1">
                                    <div className="content">
                                      
                                      <h3 style={{fontFamily: "'Acme', sans-serif"}}>{element.empName}</h3>
                                    </div>
                                  </div>
                                  <div className="face face2">
                                    <div className="content">
                                      <h6>Skills: {element.skillObj.length}</h6>
                                      <h6>COP: {correspondingCOPemployee?correspondingCOPemployee.skillObj1.length:"NO COPs Found"}</h6>
                                      <Link to={`/employeedetails/${element.empName}`}>
                                      <lord-icon
                                          src="https://cdn.lordicon.com/xhwleznj.json"
                                          trigger="loop-on-hover"
                                          delay="1000"
                                          style={{width:"50px",height:"50px"}}>
                                      </lord-icon>
                                      </Link>
                                      {/* <a href="/">Read More</a> */}
                                    </div>
                                  </div>
                                  </div>
                                  </div>
                                  
                                  )
                              })

                          }                            
                </div>
              </div>
            </div>
            
        </div>
    )
}

