import React, { useEffect, useState } from 'react'
import {  useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom'
import {emoji} from '../Emoji'
import {skills} from '../Skill'

export default function EmployeeDetails() {
    const [EmpDetails,setEmpDetails]=useState();
    const [COPEmpDetails,setCOPEmpDetails]=useState();
    const{name}=useParams();
    const hello1=useSelector(state=>state.combined);
    useEffect(()=>{
        const EmployeeDetails=hello1.Value&&hello1.Value.filter((element)=>{
            return element.empName===name;
        })
        // console.log(name)
        setEmpDetails(EmployeeDetails);
        const COPEmployeeDetails=hello1.COPValue&&hello1.COPValue.filter((element)=>{
            return element.empName===name;
        })
        // console.log(name)
        setCOPEmpDetails(COPEmployeeDetails);
    },[])
      
      
  return (
    <div>
        <div className="container py-3">
            <div className="pricing-header p-3 pb-md-4 mx-auto text-center">
                <h4 >Employee Details</h4>
            </div>
            <main>
                
                {
                    EmpDetails&&EmpDetails.map((element)=>{
                        return(
                          <>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnwinzZoa8x_8EUSKlUAmE9cPO0B4IKQV9d0PAsaoFoQ8d9nVNolIi7Cq4s4RTSOFMBkE&usqp=CAU" alt="" width="50px" height="50px" className="rounded-circle"/>
                            <div className="pricing-header p-3 pb-md-4 mx-auto text-center">
                                <h4 style={{fontFamily: "'Sofia Sans Condensed', sans-serif"}}>{element.empName}</h4>
                            </div>
                            <h1>Skills</h1>
                            <div className="row row-cols-1 row-cols-md-3 mb-3 text-center">
                            {
                              element.skillObj&&element.skillObj.map((element1)=>{
                                return(<div className="col">
                                    <div className="card mb-4 rounded-3 shadow-sm">
                                    <div className="card-body">
                                        <h3 className="card-title pricing-card-title">{element1.skill}</h3>
                                        <p><img src={skills[element1.skill]} alt="" width="40px" height="40px"/></p>
                                        <div>{emoji[element1.rating]}</div>
                                        <Link to={`/employeedetails/employeeedit/${element.empName}/${element1.skill}`}>
                                            <lord-icon
                                                src="https://cdn.lordicon.com/puvaffet.json"
                                                trigger="loop-on-hover"
                                                delay="1000"
                                                style={{width:"50px",height:"50px"}}>
                                            </lord-icon>
                                        </Link>
                                    </div>
                                    </div>
                                </div>)
                            })
                            }
                            </div>
                            <h1>COPs</h1>
                            {COPEmpDetails[0]?
                            <div className="row row-cols-1 row-cols-md-3 mb-3 text-center">
                            {
                                
                                COPEmpDetails[0].skillObj1&&COPEmpDetails[0].skillObj1.map((element1)=>{
                                return(<div className="col">
                                    <div className="card mb-4 rounded-3 shadow-sm">
                                    <div className="card-body">
                                        <h3 className="card-title pricing-card-title">{element1.skill}</h3>
                                        <p><img src={skills[element1.skill]} alt="" width="40px" height="40px"/></p>
                                        <div>{emoji[element1.rating]}</div>
                                        <Link to={`/employeedetails/employeeedit/${element.empName}/${element1.skill}`}>
                                            <lord-icon
                                                src="https://cdn.lordicon.com/puvaffet.json"
                                                trigger="loop-on-hover"
                                                delay="1000"
                                                style={{width:"50px",height:"50px"}}>
                                            </lord-icon>
                                        </Link>
                                    </div>
                                    </div>
                                </div>)
                            })
                            }
                            </div>:<h4>No COPS Found</h4>}
                          </>
                        )
                    })
                }
                
            </main>

            
        </div>
    </div>
  )
}
