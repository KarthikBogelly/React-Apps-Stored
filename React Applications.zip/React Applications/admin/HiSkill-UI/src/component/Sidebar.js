import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAward, faGraduationCap, faHouse, faUserCircle } from '@fortawesome/free-solid-svg-icons';

const Sidebar = () => {
  const [activePage, setActivePage] = useState('');
  const location = useLocation();

  useEffect(() => {
    setActivePage(location.pathname);
  }, [location.pathname]);

  return (
    <div>
      <div className="d-flex flex-column flex-shrink-0 p-3 bg-light" style={{width:"280px",height:"100vh"}}>
        <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
          <strong><span className="fs-2">HiSkill</span></strong>
        </a>
        <hr/>
        <ul className="nav nav-pills flex-column mb-auto">
          <li className="nav-item">
            <a href="/homepage" className={`nav-link ${activePage === '/homepage' ? 'active' : ''}`} aria-current="page">
              <FontAwesomeIcon className="rounded-circle me-2" icon={faHouse} />
              Home
            </a>
          </li>
          <li>
            <a href="/skillList" className={`nav-link ${activePage === '/skillList' ? 'active' : ''}`}aria-current="page">
              <FontAwesomeIcon className="rounded-circle me-2" icon={faGraduationCap} />
              Skills
            </a>
          </li>
          <li>
            <a href="/certificateList" className={`nav-link ${activePage === '/certificateList' ? 'active' : ''}`}aria-current="page">
              <FontAwesomeIcon className="rounded-circle me-2 mx-0" icon={faAward} size="lg"/>
              Certifications
            </a>
          </li>
        </ul>
        <hr/>
        <div class="dropdown">
                    <a href="/" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle mx-3 mb-2" id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
                    <FontAwesomeIcon className="rounded-circle me-1" size='xl' icon={faUserCircle} />
                        <strong>User</strong>
                    </a>
                    <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">
                        <li><a class="dropdown-item" href="/">Sign out</a></li>
                    </ul>
      </div>
    </div>
    </div>
  );
}

export default Sidebar;
