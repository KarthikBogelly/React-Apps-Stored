import React, { useRef } from "react";
import { Pie, getElementAtEvent } from "react-chartjs-2";
import { useNavigate } from "react-router-dom";

function PieChart1({ chartData }) {
  const navigate = useNavigate();
  const chartRef=useRef();
  const handleClick = (event) => {
      // console.log(chartRef);
      const value=(getElementAtEvent(chartRef.current,event).length===0?" ":getElementAtEvent(chartRef.current,event)[0].index);
      const activeElement = (value!==" ")?chartData.labels[getElementAtEvent(chartRef.current,event).length===0?" ":getElementAtEvent(chartRef.current,event)[0].index]:"ohno";
      console.log(activeElement);
      navigate(`/COPlabels/${activeElement}`);
    
    // navigate(`/labels/${activeElement}`);
  };
  return (
    <div className="chart-container">
      <h2 style={{ textAlign: "center" }}>Skills Of Employees</h2>
      <Pie
        data={chartData}
        ref={chartRef}
        onClick={(event)=>{handleClick(event)}}
      />
    </div>
  );
}
export default PieChart1;