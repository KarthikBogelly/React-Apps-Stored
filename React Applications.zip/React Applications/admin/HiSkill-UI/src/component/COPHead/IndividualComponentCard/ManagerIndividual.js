import React, { useState } from 'react'
import "./css/card.css"
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import {skills} from '../Skill'

export default function ManagerIndividual() {
    const [input,setinput]=useState("");
    const [employeeName,setemployeeName]=useState("");
    const hello1=useSelector(state=>state.combined)
    const onchangeHandler=(event)=>{
        // console.log(event.target.value);
        setinput(event.target.value);
        const Hello=hello1.Value&&hello1.Value.filter((element,index)=>{
            return element.name.toLowerCase().indexOf((event.target.value).toLowerCase())!==-1;
        });
        setemployeeName(Hello);
        // console.log(Hello);

    }
    return (
        <div>

            <div className="p-3 pb-md-4 mx-auto text-center" style={{marginTop:"30px"}}>
                <h3 className="m-4">Employee Details</h3>
                <input className="form-control" id="exampleDataList" placeholder="Enter Employee Name" value={input} onChange={onchangeHandler}/>
            </div>
            <div >
            <div className="row row-cols-1 row-cols-md-3 g-4">  
              <div className="container1">
                              {
                              
                              employeeName?employeeName.map((element)=>{
                                  return(
                                  <div className="col">
                                  <div className="card1">
                                    <div className="face face1">
                                    <div className="content">
                                      
                                      <h3 style={{fontFamily: "'Acme', sans-serif"}}>{element.name}</h3>
                                    </div>
                                  </div>
                                  <div className="face face2">
                                    <div className="content">
                                      <p>
                                        {
                                          element.ratings&&element.ratings.map((element1)=>{
                                            return(<>{<img src={skills[element1.field]} alt="" style={{height:"20px",width:"20px",margin:"10px"}}/>}</>)
                                        })
                                        }
                                      </p>
                                      {/* <p></p> */}
                                      <Link to={`/COPemployeeDetails/${element.name}`}>
                                      <lord-icon
                                          src="https://cdn.lordicon.com/xhwleznj.json"
                                          trigger="loop-on-hover"
                                          delay="1000"
                                          style={{width:"50px",height:"50px"}}>
                                      </lord-icon>
                                      </Link>
                                      {/* <a href="/">Read More</a> */}
                                    </div>
                                  </div>
                                  </div>
                                  </div>
                                  
                                  )
                              }):hello1.Value&&hello1.Value.map((element)=>{
                                return(
                                  <div className="col">
                                  <div className="card1">
                                    <div className="face face1">
                                    <div className="content">
                                      
                                      <h3 style={{fontFamily: "'Acme', sans-serif"}}>{element.name}</h3>
                                    </div>
                                  </div>
                                  <div className="face face2">
                                    <div className="content">
                                      <p>
                                        {
                                          element.ratings&&element.ratings.map((element1)=>{
                                            return(<>{<img src={skills[element1.field]} alt="" style={{height:"20px",width:"20px",margin:"10px"}}/>}</>)
                                        })
                                        }
                                      </p>
                                      {/* <p></p> */}
                                      <Link to={`/COPemployeeDetails/${element.name}`}>
                                      <lord-icon
                                          src="https://cdn.lordicon.com/xhwleznj.json"
                                          trigger="loop-on-hover"
                                          delay="1000"
                                          style={{width:"50px",height:"50px"}}>
                                      </lord-icon>
                                      </Link>
                                      {/* <a href="/">Read More</a> */}
                                    </div>
                                  </div>
                                  </div>
                                  </div>
                                  
                                  )
                              })

                          }                            
                </div>
              </div>
            </div>
            
        </div>
    )
}

