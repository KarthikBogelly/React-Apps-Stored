import React from 'react'

import ManagerIndividual from './ManagerIndividual'
import SideComponent from '../SideComponent/SideComponent'

export default function EmployeeDetailsDash() {
  return (
    <div>
      <div className="row" style={{marginRight:"0px"}}>
      
        <div className="col-4 col-md-4"><SideComponent/></div>
        <div className="col-14 col-md-6" style={{height:"100vh"}}><ManagerIndividual/></div>
        
        {/* <div className="col-md-8"><Test/></div> */}
      </div>
    </div>
  )
}
