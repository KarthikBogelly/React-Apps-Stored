import React, { useEffect, useState } from 'react'
import {  useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom'
import {emoji} from '../Emoji'
import {skills} from '../Skill'

export default function EmployeeDetails() {
    const [EmpDetails,setEmpDetails]=useState();
    const{name}=useParams();
    const hello1=useSelector(state=>state.combined)
    // const dispatch=useDispatch();
    // dispatch(actionCreators.setcontinent(event.target.hello1.Value));
    useEffect(()=>{
        const EmployeeDetails=hello1.Value&&hello1.Value.filter((element)=>{
            return element.name===name;
        })
        console.log(name)
        setEmpDetails(EmployeeDetails);
    },[])
      
      
  return (
    <div>
        <div className="container py-3">
            <div className="pricing-header p-3 pb-md-4 mx-auto text-center">
                <h4 >Employee Details</h4>
            </div>
            <main>
                
                {
                    EmpDetails&&EmpDetails.map((element)=>{
                        return(
                          <>
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnwinzZoa8x_8EUSKlUAmE9cPO0B4IKQV9d0PAsaoFoQ8d9nVNolIi7Cq4s4RTSOFMBkE&usqp=CAU" alt="" width="50px" height="50px" className="rounded-circle"/>
                            <div className="pricing-header p-3 pb-md-4 mx-auto text-center">
                                <h4 style={{fontFamily: "'Sofia Sans Condensed', sans-serif"}}>{element.name}</h4>
                            </div>
                            <div className="row row-cols-1 row-cols-md-3 mb-3 text-center">
                            {
                              element.ratings&&element.ratings.map((element1)=>{
                                return(<div className="col">
                                    <div className="card mb-4 rounded-3 shadow-sm">
                                    <div className="card-body">
                                        <h3 className="card-title pricing-card-title">{element1.field}</h3>
                                        <p><img src={skills[element1.field]} alt="" width="40px" height="40px"/></p>
                                        <div>{emoji[element1.Rating]}</div>
                                    </div>
                                    </div>
                                </div>)
                            })
                            }
                            </div>
                          </>
                        )
                    })
                }
                
            </main>

            
        </div>
    </div>
  )
}
