import React from 'react'
import { Link } from 'react-router-dom'

export default function SideComponent() {
  return (
    <div className="position-fixed">
      <div className="d-flex flex-column flex-shrink-0 p-3 bg-body-tertiary" style={{width: "280px",height:"100vh"}}>
      <svg className="bi pe-none me-2" width="40" height="32"></svg>
      <span className="fs-4">HiSkill</span>
    <hr/>
    <ul className="nav nav-pills flex-column mb-auto">
      <li className="nav-item">
        <Link to="/COPDashboard" className="nav-link link-body-emphasis" aria-current="page">
          
          Home
        </Link>
      </li>
      <li>
        <Link to="/COPemployeeDetails" className="nav-link link-body-emphasis">
          <svg className="bi pe-none me-2" width="16" height="16"></svg>
          Employee Details
        </Link>
      </li>
    </ul>
    <hr/>
    <div className="dropdown">
      <a href="/" className="d-flex align-items-center link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
        <i width="32" height="32" className="fas fa-user-circle rounded-circle me-2"></i>
        {/* <img src="https://github.com/mdo.png" alt="" width="32" height="32" className="rounded-circle me-2"/> */}
        <strong>#User</strong>
      </a>
      <ul className="dropdown-menu text-small shadow">
        <li><a className="dropdown-item" href="/">Sign out</a></li>
      </ul>
    </div>
  </div>
    </div>
  )
}
