
import React from 'react'

import IndividualSkill from './IndividualSkill'
import SideComponent from '../SideComponent/SideComponent'

export default function IndividualSkillDashboard() {
  return (
    <div>
      <div className="row" style={{marginRight:"0px"}}>
      
        <div className="col-4 col-md-4"><SideComponent/></div>
        <div className="col-14 col-md-6" style={{height:"100vh"}}><IndividualSkill/></div>
      </div>
    </div>
  )
}
