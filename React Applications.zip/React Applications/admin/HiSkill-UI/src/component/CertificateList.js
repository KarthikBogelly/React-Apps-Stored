import React from 'react';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAward } from '@fortawesome/free-solid-svg-icons';
import './CertificateList.css'

const CertificateList = () => {

    const [solution, setSolution] = useState([]);

    useEffect(() => {
        axios.get("/certificateset")
            .then((response) => {
                setSolution(response.data);
                console.log(response.data);
            })
            .catch((error) => {
                console.error(error);
            });
    }, []);

    return (
        <div>
            <hr style={{ height: "2px", borderWidth: "0", color: "gray", backgroundColor: "grey" }}></hr>
            <h1 className="display-5 fw-bold text-center" style={{color: "#333333"}}>Certifications</h1>
            <hr style={{ height: "2px", borderWidth: "0", color: "gray", backgroundColor: "grey" }}></hr>
            <div className="row row-cols-1 row-cols-md-2 g-4 mx-3 mt-3">
                {solution && solution.map((element) => {
                    return (
                        <div key={element.certificateId} className="card certificate-card text-dark bg-light my-3 mt-3 mx-3 mb-3" style={{ height:"100%",maxHeight: "30rem", width: "17rem", borderRadius: "15px", boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)", transition: "transform 0.2s", overflow: "hidden", cursor:"pointer"}}>
                            <center>
                                <div className="card-header" style={{ backgroundColor: "#F8F9FA", borderRadius: "15px 15px 0 0", padding: "1.5rem 1rem" }}>
                                    <FontAwesomeIcon icon={faAward} size="3x" style={{ marginBottom: "1rem", color: "#FDD83C" }} />
                                    <h5 className="display-7 col d-flex justify-content-center mt-1">{element.certificatename}</h5>
                                </div>
                                <div className="card-body" style={{ padding: "1rem 1rem 2rem" }}>
                                    <p className="card-text"><b>ID: </b>{element.certificateId}</p>
                                    <p className="card-text"><b>COP: </b>{element.cop}</p>
                                    <p className="card-text"><b>SUBCOP: </b>{element.subcop}</p>
                                    <p className="card-text"><b>VERSION: </b>{element.version}</p>
                                    <p className="card-text"><b>IS DEPRECATED: </b>{element.isdepricted ? "true" : "false"}</p>
                                </div>
                            </center>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

export default CertificateList;

