import React from 'react'


import { useState } from 'react';

import { Slider, ThemeProvider,createTheme } from '@mui/material';



export default function EmployeeMainComponent() {
    // const [ value5, setValue5 ] = React.useState([0]);
    const [ colorChange, setcolorChange ] = React.useState("#BBD6B8");
    const [textboxes, setTextboxes] = useState([{
      field:"",
      rating:0
    }]);
    const onclickHandler=(event)=>{
        setTextboxes([...textboxes,{
          field:"",
          rating:0
        }]);
        
    }
    const onchangeslider=(index,value)=>{
      const newValues = [...textboxes];
      console.log(newValues);
      newValues[index].rating = parseInt(value);
      setTextboxes(newValues);

    }
    const handleTextboxChange=(event,index)=>{
      const newValues = [...textboxes];
      newValues[index].field = event.target.value;
      setTextboxes(newValues);
    }
    const onSubmitHandler=()=>{
      console.log(textboxes);
    }
    const onclickDeleteHandler=(event,index)=>{
      if(textboxes.length!==1){
        const newValues=textboxes&&textboxes.filter((element,index1)=>{
          return index1!==index;
        })
        console.log(newValues);
        setTextboxes(newValues);

      }
      else{
        console.log("Hello");
        setTextboxes([{
          field:"",
          rating:0
        }]);
        // setValue5([''])
      }

    }
    const muiTheme = createTheme({
      overrides:{
        MuiSlider: {
          thumb:{
          color: "yellow",
          },
          track: {
            color: 'red'
          },
          rail: {
            color: 'black'
          }
        }
    }
    });
  return (
    <div>
        <div className="px-4 pt-5 my-5 text-center">
    <h3 className="display-6 fw-bold " style={{color:"#52616B",cursor:"default",marginBottom:"25px"}} >Skills & Rating</h3>
    <div className="col-lg-8 mx-auto">
      <div className="card">
        <div className="card-body">
                <form >
                    {
                        textboxes&&textboxes.map((value, index) => (
                          <div className="row g-2 m-3">
                            <div className="col">
                                <label className="visually-hidden">Skills</label>
                                <input type="text" className="form-control" id="Text" placeholder="Skills" value={value.field} onChange={(e) => handleTextboxChange(e, index)}/>
                            </div>
                            <div className="col" style={{width:"60px"}}>
                            <div className="row m-2">
                              {console.log(value)}
                              <div className="col" >
                                    
                                    <ThemeProvider theme={muiTheme}>
                                        <Slider
                                          // aria-label="Temperature"
                                          defaultValue={0}
                                          // getAriaValueText={value.rating}
                                          value={value.rating}
                                          valueLabelDisplay="auto"
                                          step={1}
                                          marks
                                          min={0}
                                          max={5}
                                          onChange={(event)=>{onchangeslider(index,event.target.value)}}
                                        />
                                        </ThemeProvider>
                                    {/* <PrettoSlider
                                      valueLabelDisplay="auto"
                                      aria-label="pretto slider"
                                      value={value.rating}
                                      defaultValue={0}
                                      marks
                                      onChange={(event)=>{onchangeslider(index,event.target.value)}}
                                    /> */}

                                {/* <Slider/> */}
                                {/* <CircularSlider
                                    r={50}
                                    trackWidth={10}
                                    thumbWidth={10}
                                    onChange={value => console.log(value)}
                                  /> */}
                              </div>
                              <div className="col">
                              <button type="button" className="btn" onClick={(event)=>{onclickDeleteHandler(event,index)}}>
                              <lord-icon
                                  src="https://cdn.lordicon.com/jmkrnisz.json"
                                  trigger="loop-on-hover"
                                  delay="1000"
                                  colors="primary:#e83a30"
                                  style={{width:"25px",height:"25px",color:"red"}}
                                  
                                  >
                              </lord-icon>
                              </button>
                  
                              </div>
                            </div>
                        </div>
                        </div>
                        ))
                    }
                </form>
                <div className="d-grid gap-2 d-sm-flex justify-content-sm-center mb-5">
                    <button type="button" className="btn btn-outline-secondary btn-lg px-3" onClick={onclickHandler}>Add Skill</button>
                    <button type="button" className="btn btn-outline-secondary btn-lg px-3" onClick={onSubmitHandler}>Submit</button>
                </div>
        </div>
      </div>
    </div>
  </div>
        {/* <h5 className="display-5 fw-bold text-body-emphasis">Centered screenshot</h5> */}
    </div>
  )
}

