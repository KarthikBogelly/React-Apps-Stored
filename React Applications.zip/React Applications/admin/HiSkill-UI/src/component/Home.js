import React from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div><div class="container">
    <header class="d-flex justify-content-center py-3">
      <ul class="nav nav-pills">
        <li class="nav-item">
            <Link to="/ManagerHome" class="nav-link " aria-current="page">Manager</Link></li>
        <li class="nav-item">
            <Link to="/COPDashboard" class="nav-link">COP</Link>
        </li>
      </ul>
    </header>
  </div></div>
  )
}
