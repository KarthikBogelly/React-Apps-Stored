import React from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  return (
    <div className="container" style={{paddingTop:"45px"}}>
      <div className="row">
        <div className="col-md-8 mx-auto">
          <div className="jumbotron text-center mt-5" style={{ backgroundColor: "#C4CAD6", borderRadius: "10px", padding: "3rem" }}>
            <h1 className="display-4">Welcome to HiSkill</h1>
            <p className="lead">Upgrade Your Skills, Unlock Your Potential</p>
            <hr className="my-4" style={{ borderColor: "#343A40" }} />
            <p className="text-muted">HiSkill is the perfect platform to help you achieve your goals. Browse our collection of skills and solutions, or add a new one to share with the community!</p>
            <hr className="my-4" style={{ borderColor: "#343A40" }} />
            <Link to='/skillList'><button className="btn btn-lg btn-primary">Browse Catalog</button></Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HomePage;