import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import EmployeeDashboard from './component/ManagerDashboard/EmployeeDashboard/EmployeeDashboard';
import ManagerEditDashboard from './component/ManagerDashboard/ManagerEdit/ManagerEditDashboard'
import EmployeeDetailsDash from './component/ManagerDashboard/IndividualComponentCard/EmployeeDetailsDash';
import EmployeeDetailsIndividual from './component/ManagerDashboard/Employee Individual/EmployeeDetailsIndividual'
import IndividualSkillDashboard from './component/ManagerDashboard/SelectiveSkill/IndividualSkillDashboard';
import HomeManager from './component/ManagerDashboard/HomeManager/HomeManager'


import COPEmployeeDashboard from './component/COPHead/EmployeeDashboard/EmployeeDashboard';
import COPEmployeeDetailsDash from './component/COPHead/IndividualComponentCard/EmployeeDetailsDash';
import COPEmployeeDetailsIndividual from './component/COPHead/Employee Individual/EmployeeDetailsIndividual'
import COPIndividualSkillDashboard from './component/COPHead/SelectiveSkill/IndividualSkillDashboard';
import Home from './component/Home';
import NotfoundDash from './component/ManagerDashboard/Notfoundpage/NotfoundDash';
import Sidebar from './component/Sidebar';
import SkillList from './component/SkillList';
import AddSkill from './component/AddSkill';
import CertificateList from './component/CertificateList';
import HomePage from './component/HomePage';
function App() {
  return (
    <div className="App" style={{height:"100%"}}>
      <BrowserRouter>
      <Routes>
          <div className="app-container">
            <div className="sidebar-container">
              <Sidebar />
            </div>
            <div className="applist-container">
              <Routes>
                <Route path="/" element={<Home/>} />
                <Route path="/skillList" element={<SkillList />} />
                <Route path="/homepage" element={<HomePage/>} />
                <Route path="/addSkill" element={<AddSkill/>} />
                <Route path="/certificateList" element={<CertificateList/>} />
              </Routes>
            </div>
          </div>
          <Route exact path="/" Component={Home}/>
          <Route exact path="/ManagerHome" Component={HomeManager}/>
          <Route exact path="/ManagerDashboard" Component={EmployeeDashboard}/>
          <Route exact path="/employeeDetails" Component={EmployeeDetailsDash}/>
          <Route exact path="/labels/employeeedit/:name/:skill" Component={ManagerEditDashboard}/>
          <Route exact path="/employeedetails/employeeedit/:name/:skill" Component={ManagerEditDashboard}/>
          <Route exact path="/employeedetails/:name" Component={EmployeeDetailsIndividual}/>
          <Route exact path="/labels/ohno" Component={NotfoundDash}/>
          <Route exact path="/labels/:skill" Component={IndividualSkillDashboard}/>
          <Route exact path="/COPDashboard" Component={COPEmployeeDashboard}/>
          <Route exact path="/COPemployeeDetails" Component={COPEmployeeDetailsDash}/>
          <Route exact path="/COPemployeeDetails/:name" Component={COPEmployeeDetailsIndividual}/>
          <Route exact path="/COPlabels/:skill" Component={COPIndividualSkillDashboard}/>
        </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;



