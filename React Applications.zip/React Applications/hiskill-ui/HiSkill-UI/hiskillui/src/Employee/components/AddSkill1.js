import React from 'react'
import background from '../assets/AddSkill assests/BackgroundScreen.svg';
import addskillcard from '../assets/AddSkill assests/Addskill Card.svg';
import { HvGrid, HvDropdown } from '@hitachivantara/uikit-react-core';
export default function AddSkill1() {
  return (
    <div>
       <div className='background'>
            <img
                alt="rectangle"
                src={background}
                style={{
                position: "absolute",
                width: "100vw",
                height: "100vh",
                objectFit: "cover",
                }}
            />
       </div>
       <div className='addskill-card'>
            <img
                alt="addskillcard"
                src={addskillcard}
                style={{
                position: "absolute",
                width: "918px",
                height: "100%",
                maxHeight:'500px',
                left: "181px",
                top: "50px",
                }}
            />
            <HvGrid container>
            <HvGrid
            container
            item
            xs={5}
            >
            <HvGrid
                item
                xs={12}
            >
                <HvDropdown
                aria-label="With max height"
                hasTooltips
                maxHeight={350}
                showSearch
                values={[
                    {
                    id: '0',
                    label: 'value  0'
                    },
                    {
                    id: '1',
                    label: 'value  1'
                    },
                    {
                    id: '2',
                    label: 'value  2'
                    },
                    {
                    id: '3',
                    label: 'value  3'
                    }
                ]}
                style={{
                    left:'380px',
                    top:'100px',
                    borderRadius:'100px',
                    backgroundColor:'#D17A7C',
                    width:'250px',
                    
                }}
      
                />
            </HvGrid>
            </HvGrid>
        </HvGrid>
       </div>
    </div>
  )
}
