import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  HvCard,
  HvCardContent,
  HvDatePicker,
  HvSlider,
  HvGlobalActions,
  HvDropdown,
  HvLoading,
} from '@hitachivantara/uikit-react-core';

const Form = () => {
  const [proficiencylevel, setProficiencyLevel] = useState(1);
  const [proficiencyLevelError, setProficiencyLevelError] = useState('');
  const [lastused, setlastused] = useState(null);
  const [lastusedError, setlastusedError] = useState('');
  const [dropdownValue, setDropdownValue] = useState('');
  const [dropdownOptions, setDropdownOptions] = useState([]);
  const [dropdownError, setDropdownError] = useState('');
  const [loading, setLoading] = useState(false);


  useEffect(() => {
    fetchSkillOptions();
  }, []);

  const fetchSkillOptions = () => {
    axios
      .get('http://13.234.20.12:8080/api/v1/skillmaster')
      .then((response) => {
        console.log(response.data);
        const skillNames = response.data.map((skill) => ({
          label: skill.skillname,
          value: skill.skillid,
        }));
        setDropdownOptions(skillNames);
      })
      .catch((error) => {
        console.error('Error fetching skill options:', error);
      });
  };

  const handleProficiencyChange = (value) => {
    const parsedValue = parseInt(value, 10);
    setProficiencyLevel(parsedValue);
    };

  const handleRecentlyUsedChange = (date) => {
    setlastused(date);
  };

  const handleDropdownChange = (event) => {
    setDropdownValue(event.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validateForm()) {
      setLoading(true);

      const formData = {
        proficiencylevel,
        lastused,
        empId: 1,
        createdby:null,
        createddate:null,
        updatedby:null,
        updateddate:null,
        skillid: dropdownValue,
      };
      setProficiencyLevel(1);
      setlastused(null);
      setDropdownValue('');
      axios
        .post('http://13.234.20.12:8080/api/v1/skillemp', formData)
        .then((response) => {
          console.log('Form submitted:', response.data);
          setProficiencyLevel(1);
          setlastused(null);
          setDropdownValue('');
          setLoading(false);
        })
        .catch((error) => {
          console.error('Error submitting form:', error);
          setLoading(false);
        });
    }
  };

  const validateForm = () => {
    let isValid = true;

    if (proficiencylevel === 0) {
      setProficiencyLevelError('Proficiency is required');
      isValid = false;
    } else {
      setProficiencyLevelError('');
    }

    if (!lastused) {
      setlastusedError('Recently Used date is required');
      isValid = false;
    } else {
      setlastusedError('');
    }

    if (dropdownValue === '') {
      setDropdownError('Dropdown value is required');
      isValid = false;
    } else {
      setDropdownError('');
    }

    return isValid;
  };

  const isFormValid = proficiencylevel !== 0 && lastused && dropdownValue !== '';

  return (
    <>
      <HvGlobalActions style={{ marginTop: '15px' }} title="Enter the details below" />
      <div
        style={{
          margin: 20,
          marginTop: 20,
          marginLeft: 150,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          paddingRight: '10px',
          position: 'absolute',
        }}
      >
        <HvCard
          bgcolor="atmo1"
          selectable
          selected
          statusColor="negative"
          style={{ width: 600, padding: '20px', height: '65vh' }}
        >
          <HvCardContent>
            <form onSubmit={handleSubmit}>
              <div style={{ marginTop: '50px', marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label
                  htmlFor="dropdown"
                  style={{
                    fontWeight: 'bold',
                    minWidth: '120px',
                  }}
                >
                  Skill Name :
                </label>
                <div style={{ flex: '1' }}>
                  <HvDropdown
                    id="dropdown"
                    aria-label="With max height"
                    hasTooltips
                    maxHeight={350}
                    showSearch
                    placeholder="Select skill here"
                    values={dropdownOptions}
                    value={dropdownValue}
                    onChange={(event)=>{handleDropdownChange(event)}}
                  />
                </div>
              </div>
              {dropdownError && (
                <div style={{ color: 'red', marginLeft: '10px' }}>{dropdownError}</div>
              )}
              <div
                style={{
                  marginTop: '60px',
                  marginBottom: '50px',
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <label
                  htmlFor="proficiency"
                  style={{
                    marginRight: '10px',
                    fontWeight: 'bold',
                    minWidth: '120px',
                  }}
                >
                  Proficiency :
                </label>
                <div style={{ flex: '1' }}>
                  <HvSlider
                    id="proficiency"
                    markStep={1}
                    divisionQuantity={4}
                    maxPointValue={5}
                    minPointValue={1}
                    defaultValues={[0]}
                    value={proficiencylevel}
                    onChange={handleProficiencyChange}
                    style={{ width: '104%' }}
                    hideInput
                    required
                  />
                </div>
              </div>
              {proficiencyLevelError && (
                <div style={{ color: 'red', marginLeft: '10px' }}>{proficiencyLevelError}</div>
              )}
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label
                  htmlFor="recentlyUsed"
                  style={{
                    marginRight: '10px',
                    fontWeight: 'bold',
                    minWidth: '120px',
                  }}
                >
                  Recently Used :
                </label>
                <div style={{ flex: '1' }}>
                  <HvDatePicker
                    aria-label="Date"
                    id="recentlyUsed"
                    locale="en-US"
                    value={lastused}
                    onChange={handleRecentlyUsedChange}
                    onCancel={() => setlastused(null)}
                    onClear={() => setlastused(null)}
                    placeholder="Select date"
                    status="standBy"
                    placement="right"
                    style={{ width: '85', paddingLeft: '10px', position: 'relative', zIndex: '9999' }}
                  />
                </div>
              </div>
              {lastusedError && (
                <div style={{ color: 'red', marginLeft: '10px' }}>{lastusedError}</div>
              )}
              <button
                type="submit"
                style={{
                  backgroundColor: isFormValid ? '#4CAF50' : '#ccc',
                  color: 'white',
                  padding: '10px 20px',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: isFormValid ? 'pointer' : 'not-allowed',
                  fontWeight: 'bold',
                  position: 'relative',
                }}
                disabled={!isFormValid || loading}
              >
                {loading ? (
                  <div
                    style={{
                      position: 'absolute',
                      top: '50%',
                      left: '50%',
                      transform: 'translate(-50%, -50%)',
                    }}
                  >
                    <HvLoading label="Loading" />
                  </div>
                ) : (
                  'Submit'
                )}
              </button>
            </form>
          </HvCardContent>
        </HvCard>
      </div>
    </>
  );
};

export default Form;
