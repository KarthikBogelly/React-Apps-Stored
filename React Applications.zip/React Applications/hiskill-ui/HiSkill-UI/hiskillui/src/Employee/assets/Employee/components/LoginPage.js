import React from 'react';
import {HvInput,HvButton,HvTypography,HvCard,HvCardContent,HvHeader,HvGrid,HvDropdown} from '@hitachivantara/uikit-react-core';
import {useNavigate} from 'react-router-dom';
export default function LoginPage() {

const [selectedOption,setSelectedOption] = React.useState('');
const navigate = useNavigate();



const handleSubmit = (event) => {
    event.preventDefault();
    if(selectedOption === 'Admin')
    {
        navigate('/skilltable');
    }
    else if(selectedOption === 'Employee')
    {
        navigate('/home');
    }
    else if(selectedOption === 'RMG')
    {
        navigate('/addskill');
    }
    else if(selectedOption === 'COPLead')
    {
        navigate('/logoutpage');
    }
    else if(selectedOption === 'Manager')
    {
        navigate('/manager');
    }
    return navigate;

}
  return (
    <>
    <div
    style={{
        height: 80,
        overflowX:'hidden',
    }}
    >
    <div
        style={{
        minHeight: 100
        }}
    >
        <HvHeader style={{height:'70px', boxShadow:'10px 5px 10px rgba(0,0,0,0.1)'}} position="fixed">
       
        <div
            style={{
                width: 1500,
                textAlign: 'center',
                paddingBottom:'8px',
            }}
            >
            <HvTypography
                variant="title1"
            >
                Login Page
            </HvTypography>
            </div>
        </HvHeader>
    </div>
    </div>
    <div
        style={{
            marginLeft:400
        }}
        >
        <HvCard
            bgcolor="atmo1"
            statusColor="negative"
            style={{
            width: 500,
            height: '100%',
            maxHeight: 1000,
            marginTop:40,
            paddingLeft:50,
            paddingRight:50,
            }}
        >
            <div
                style={{
                    width: 420,
                    paddingTop: 30,
                    textAlign: 'center',
                }}
                >
                <HvTypography
                    variant="title2"
                >
                Enter your details below
                </HvTypography>
            </div>
            <div
                style={{
                    paddingTop: '30px',
                    paddingLeft:'15px',
                    width: '935px',
                }}
            >
            <HvGrid container>
                <HvGrid
                container
                item
                xs={5}
                >
                <HvGrid
                    item
                    xs={12}
                >
                    <HvDropdown
                    aria-label="With max height"
                    maxHeight={350}
                    placeholder="Select designation here..."
                    onChange = {(event) => setSelectedOption(event.value)}
                    values={[
                        {
                        id: '0',
                        label: 'Admin'
                        },
                        {
                        id: '1',
                        label: 'Employee'
                        },
                        {
                        id: '2',
                        label: 'RMG'
                        },
                        {
                        id: '3',
                        label: 'COPLead'
                        },
                        {
                        id: '4',
                        label: 'Manager'
                        }

                    ]}
                    />
                </HvGrid>
                </HvGrid>
            </HvGrid>
            </div>
            <HvCardContent>
            <form onSubmit = {handleSubmit}>
            <div
                style={{
                paddingTop: '30px'
                }}
            >
            <HvInput
                label="Username"
                placeholder="Enter username here"
                required
            />
            </div>
            <div
                style={{
                marginTop: '40px'
                }}
            >
            <HvInput
                id="password-input"
                label="Password"
                maxCharQuantity={24}
                minCharQuantity={8}
                placeholder="Enter your password"
                required
                type="password"               
            />
            </div>
            <div
                style={{
                marginTop: '40px',
                marginBottom: '30px',
                textAlign: 'center'
                }}
            >
            <HvButton
                overrideIconColors
                radius="base"
                variant="primary"
                >
                Submit
            </HvButton>
            </div>
            </form>
            </HvCardContent>
        </HvCard>
    </div> 
    </>    
  )
}
