import React from 'react'
import './EmpRoutes.css'
import Sidebar from './Sidebar';
import SkillTable from './SkillTable';
import AddSkill from './AddSkill';
import HomePage from './HomePage';
import { Route, Routes } from 'react-router-dom';
import CertTable from './CertTable';
import LoginPage from './LoginPage';
import LogoutPage from './LogoutPage';
export default function EmpRoutes() {
  return ( 
      <div>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/loginpage" element={<LoginPage />} />
            <Route path="/logoutpage" element={<LogoutPage />} />
            <Route path="/home" element={
                                        <div  className="app-content">
                                          <div className="sidebar">
                                              <Sidebar />
                                          </div>
                                          <div className="content">
                                            <HomePage />
                                          </div>
                                        </div>
                                        } />
            <Route path="/skilltable" element={
                                            <div  className="app-content">
                                                <div className="sidebar">
                                                    <Sidebar />
                                                </div>
                                                <div className="content">
                                                  <SkillTable />
                                                </div>
                                              </div>} />
            <Route path="/addskill" element={
                                           <div  className="app-content">
                                                <div className="sidebar">
                                                    <Sidebar />
                                                </div>
                                                <div className="content">
                                                  <AddSkill />
                                                </div>
                                              </div>} />
            <Route path="/certtable" element={
                                             <div  className="app-content">
                                                <div className="sidebar">
                                                    <Sidebar />
                                                </div>
                                                <div className="content">
                                                  <CertTable />
                                                </div>
                                              </div>} />
          </Routes>
        
      </div>
  )
}