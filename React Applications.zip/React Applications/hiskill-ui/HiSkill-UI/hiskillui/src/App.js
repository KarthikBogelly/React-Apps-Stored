import React from 'react';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import EmpRoutes from './Employee/components/EmpRoutes';
import AddSkill from './Employee/components/AddSkill';
import SkillTable from './Employee/components/SkillTable';
function App() {
  return (
    <BrowserRouter>
    <EmpRoutes></EmpRoutes>
    {/* <SkillTable></SkillTable> */}
    </BrowserRouter>
    // <AddSkillDemo>
    // </AddSkillDemo>
  // <ManagerRoutes></ManagerRoutes>

   )
}

export default App;










